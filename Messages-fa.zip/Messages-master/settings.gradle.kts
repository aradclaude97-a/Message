/*
 * SPDX-FileCopyrightText: Saalim Quadri <danascape@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

pluginManagement {
    includeBuild("PvotLib/build-logic")
    repositories {
        gradlePluginPortal()
        google()
        mavenCentral()
        maven("https://jitpack.io")
        maven("https://maven.google.com")
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven("https://jitpack.io")
        maven("https://maven.google.com")
    }
}

rootProject.name = "Messages"

includeBuild("PvotLib") {
    dependencySubstitution {
        substitute(module("com.prauga.pvot:design-system-views"))
            .using(project(":design-system-views"))
    }
}

include(":presentation")

include(":android-smsmms")

include(":domain")

include(":data")

include(":common")

include(":app")

include(":carrier-configs")

include(":gif-encoder")

include(":otp-detector")

include(":mms-pdu")

include(":telephony")
