/*
 * SPDX-FileCopyrightText: Saalim Quadri <danascape@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.receiver

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import ir.pmessages.app.receiver.SendSmsReceiver.Companion.ACTION_RETRY
import ir.pmessages.app.receiver.SendSmsReceiver.Companion.shouldSend

class SendSmsReceiverRuleTest {

    @Test
    fun givenRetryFromTheNotification_whenTheMessageFailed_thenItIsSent() {
        assertTrue(shouldSend(ACTION_RETRY, failed = true, waiting = false))
    }

    @Test
    fun givenRetryFromTheNotification_whenItIsAlreadySendingAgain_thenItIsNotSentTwice() {
        assertFalse(shouldSend(ACTION_RETRY, failed = false, waiting = true))
    }

    @Test
    fun givenRetryFromTheNotification_whenItWentThroughSince_thenItIsNotSentAgain() {
        assertFalse(shouldSend(ACTION_RETRY, failed = false, waiting = false))
    }

    @Test
    fun givenTheDelayedSendAlarm_whenTheMessageIsWaiting_thenItIsSent() {
        assertTrue(shouldSend(null, failed = false, waiting = true))
    }

    @Test
    fun givenTheDelayedSendAlarm_whenTheMessageIsGone_thenNothingIsSent() {
        assertFalse(shouldSend(null, failed = false, waiting = false))
    }

    @Test
    fun givenANotificationFromBeforeTheUpdate_whenTheMessageFailed_thenItIsSent() {
        assertTrue(shouldSend(null, failed = true, waiting = false))
    }
}
