/*
 * SPDX-FileCopyrightText: 2025 gavine99 <github@xymail.tk>
 * SPDX-FileCopyrightText: Saalim Quadri <danascape@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.util

import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.contentValuesOf
import androidx.core.net.toFile
import java.io.File
import java.io.OutputStream
import ir.pmessages.app.extensions.isEmpty

class FileUtils {
    companion object {
        enum class Location {
            Downloads,
            ExternalCache,
            Cache,
            Files,
            Obb,
            CodeCache,
            NoBackup,
        }

        fun create(location: Location, context: Context, filename: String, mimeType: String) =
            if (location == Location.Downloads) createDownloadsFile(context, filename, mimeType)
            else createLocation(location, context, filename)

        private fun createDownloadsFile(
            context: Context,
            filename: String,
            mimeType: String,
        ): Pair<Uri, Exception?> =
            try {
                val uri =
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) { // use media store
                        context.contentResolver.insert(
                            MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                            contentValuesOf(
                                MediaStore.MediaColumns.MIME_TYPE to mimeType,
                                MediaStore.MediaColumns.RELATIVE_PATH to
                                    Environment.DIRECTORY_DOWNLOADS,
                                MediaStore.MediaColumns.DISPLAY_NAME to filename,
                            ),
                        ) ?: Uri.EMPTY
                    } else { // use direct access to 'external' dir
                        File(Environment.getExternalStorageDirectory(), filename).let {
                            if (tryOrNull { it.createNewFile() } == true) Uri.fromFile(it)
                            else Uri.EMPTY
                        }
                    }

                if (uri.isEmpty()) throw Exception("Opening file returned an empty uri")

                Pair(uri, null)
            } catch (e: Exception) {
                Pair(Uri.EMPTY, e)
            }

        private fun createLocation(
            location: Location,
            context: Context,
            filename: String,
        ): Pair<Uri, Exception?> =
            try {
                val uri =
                    File(
                            when (location) {
                                Location.ExternalCache -> context.externalCacheDir
                                Location.Files -> context.filesDir
                                Location.Obb -> context.obbDir
                                Location.CodeCache -> context.codeCacheDir
                                Location.NoBackup -> context.noBackupFilesDir
                                else -> context.cacheDir
                            },
                            filename,
                        )
                        .let {
                            if (tryOrNull { it.createNewFile() } == true) Uri.fromFile(it)
                            else Uri.EMPTY
                        }

                if (uri.isEmpty()) throw Exception("Opening file returned an empty uri")

                Pair(uri, null)
            } catch (e: Exception) {
                Pair(Uri.EMPTY, e)
            }

        private fun writeBytes(
            context: Context,
            uri: Uri,
            bytes: ByteArray,
            mode: String,
        ): Exception? = writeStream(context, uri, mode) { it.write(bytes) }

        private fun writeStream(
            context: Context,
            uri: Uri,
            mode: String,
            write: (OutputStream) -> Unit,
        ): Exception? =
            try {
                context.contentResolver.openOutputStream(uri, mode)?.use(write)
                null
            } catch (e: Exception) {
                e
            }

        fun append(context: Context, uri: Uri, bytes: ByteArray): Exception? =
            writeBytes(context, uri, bytes, "wa")

        fun write(context: Context, uri: Uri, bytes: ByteArray): Exception? =
            writeBytes(context, uri, bytes, "w")

        fun truncateAndWrite(context: Context, uri: Uri, bytes: ByteArray): Exception? =
            writeBytes(context, uri, bytes, "wt")

        fun createAndWrite(
            context: Context,
            location: Location,
            filename: String,
            mimeType: String,
            bytes: ByteArray,
        ): Pair<Uri, Exception?> =
            createAndWrite(context, location, filename, mimeType) { it.write(bytes) }

        /** Like the [ByteArray] version, but [write] streams the content into the file */
        fun createAndWrite(
            context: Context,
            location: Location,
            filename: String,
            mimeType: String,
            write: (OutputStream) -> Unit,
        ): Pair<Uri, Exception?> =
            create(location, context, filename, mimeType).let { (uri, e) ->
                if (e is Exception) Pair(Uri.EMPTY, e)
                else {
                    val we = writeStream(context, uri, "w", write)
                    if (we is Exception) {
                        deleteFile(uri)
                        Pair(Uri.EMPTY, we)
                    } else Pair(uri, null)
                }
            }

        fun deleteFile(uri: Uri): Boolean {
            return try {
                if (uri == Uri.EMPTY) false else uri.toFile().delete()
            } catch (e: Exception) {
                false
            }
        }

        fun renameTo(fromUri: Uri, toUri: Uri): Boolean =
            try {
                fromUri.toFile().renameTo(toUri.toFile())
            } catch (e: Exception) {
                false
            }
    }
}
