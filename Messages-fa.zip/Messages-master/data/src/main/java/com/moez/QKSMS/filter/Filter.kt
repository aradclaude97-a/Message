/*
 * SPDX-FileCopyrightText: 2017 Moez Bhatti <moez.bhatti@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.filter

abstract class Filter<in T> {

    abstract fun filter(item: T, query: CharSequence): Boolean
}
