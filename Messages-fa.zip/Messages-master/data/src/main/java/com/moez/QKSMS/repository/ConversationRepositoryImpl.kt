/*
 * SPDX-FileCopyrightText: 2018 Moez Bhatti <moez.bhatti@gmail.com>
 * SPDX-FileCopyrightText: Saalim Quadri <danascape@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.repository

import android.content.ContentUris
import android.content.Context
import io.reactivex.Completable
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import io.realm.Case
import io.realm.Realm
import io.realm.RealmResults
import io.realm.Sort
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import ir.pmessages.app.compat.TelephonyCompat
import ir.pmessages.app.extensions.anyOf
import ir.pmessages.app.extensions.asObservable
import ir.pmessages.app.extensions.map
import ir.pmessages.app.extensions.removeAccents
import ir.pmessages.app.filter.ConversationFilter
import ir.pmessages.app.mapper.CursorToConversation
import ir.pmessages.app.mapper.CursorToRecipient
import ir.pmessages.app.model.Contact
import ir.pmessages.app.model.Conversation
import ir.pmessages.app.model.Message
import ir.pmessages.app.model.Recipient
import ir.pmessages.app.model.SearchItem
import ir.pmessages.app.util.PhoneNumberUtils
import ir.pmessages.app.util.tryOrNull

class ConversationRepositoryImpl
@Inject
constructor(
    private val context: Context,
    private val conversationFilter: ConversationFilter,
    private val cursorToConversation: CursorToConversation,
    private val cursorToRecipient: CursorToRecipient,
    private val phoneNumberUtils: PhoneNumberUtils,
) : ConversationRepository {

    override fun getConversations(
        unreadAtTop: Boolean,
        archived: Boolean,
        onlyUnread: Boolean,
    ): RealmResults<Conversation> {
        val sortOrder: MutableList<String> = arrayListOf("pinned", "draft", "lastMessage.date")
        val sortDirections: MutableList<Sort> =
            arrayListOf(Sort.DESCENDING, Sort.DESCENDING, Sort.DESCENDING)

        if (unreadAtTop) {
            sortOrder.add(0, "lastMessage.read")
            sortDirections.add(0, Sort.ASCENDING)
        }

        val realm = Realm.getDefaultInstance()
        val query =
            realm
                .where(Conversation::class.java)
                .notEqualTo("id", 0L)
                .equalTo("archived", archived)
                .equalTo("blocked", false)
                .isNotEmpty("recipients")
                .beginGroup()
                .isNotNull("lastMessage")
                .or()
                .isNotEmpty("draft")
                .endGroup()
        if (onlyUnread) {
            query.equalTo("lastMessage.read", false)
        }

        return query.sort(sortOrder.toTypedArray(), sortDirections.toTypedArray()).findAllAsync()
    }

    override fun getConversationsSnapshot(unreadAtTop: Boolean): List<Conversation> {
        val sortOrder: MutableList<String> = arrayListOf("pinned", "draft", "lastMessage.date")
        val sortDirections: MutableList<Sort> =
            arrayListOf(Sort.DESCENDING, Sort.DESCENDING, Sort.DESCENDING)

        if (unreadAtTop) {
            sortOrder.add(0, "lastMessage.read")
            sortDirections.add(0, Sort.ASCENDING)
        }

        return Realm.getDefaultInstance().use { realm ->
            realm.refresh()
            realm
                .where(Conversation::class.java)
                .notEqualTo("id", 0L)
                .equalTo("archived", false)
                .equalTo("blocked", false)
                .isNotEmpty("recipients")
                .beginGroup()
                .isNotNull("lastMessage")
                .or()
                .isNotEmpty("draft")
                .endGroup()
                .sort(sortOrder.toTypedArray(), sortDirections.toTypedArray())
                .findAll()
                .let(realm::copyFromRealm)
        }
    }

    override fun getTopConversations() =
        Realm.getDefaultInstance().use { realm ->
            realm
                .where(Conversation::class.java)
                .notEqualTo("id", 0L)
                .isNotNull("lastMessage")
                .beginGroup()
                .equalTo("pinned", true)
                .or()
                .greaterThan(
                    "lastMessage.date",
                    System.currentTimeMillis() - TimeUnit.DAYS.toMillis(7),
                )
                .endGroup()
                .equalTo("archived", false)
                .equalTo("blocked", false)
                .isNotEmpty("recipients")
                .findAll()
                .let(realm::copyFromRealm)
                .sortedWith(
                    compareByDescending<Conversation> { conversation -> conversation.pinned }
                        .thenByDescending { conversation ->
                            realm
                                .where(Message::class.java)
                                .equalTo("threadId", conversation.id)
                                .greaterThan(
                                    "date",
                                    System.currentTimeMillis() - TimeUnit.DAYS.toMillis(7),
                                )
                                .count()
                        }
                )
        }

    override fun setConversationName(id: Long, name: String) =
        Completable.fromAction {
                Realm.getDefaultInstance().use { realm ->
                    realm.executeTransaction {
                        realm.where(Conversation::class.java).equalTo("id", id).findFirst()?.name =
                            name
                    }
                }
            }
            .subscribeOn(
                Schedulers.io()
            ) // Ensure the operation is performed on a background thread

    override fun searchConversationsGrouped(query: CharSequence): List<SearchItem> =
        Realm.getDefaultInstance().use { realm ->
            val normalizedQuery = query.removeAccents()

            val matches =
                realm
                    .where(Message::class.java)
                    .beginGroup()
                    .contains("body", normalizedQuery, Case.INSENSITIVE)
                    .or()
                    .contains("parts.text", normalizedQuery, Case.INSENSITIVE)
                    .endGroup()
                    .sort("date", Sort.DESCENDING)
                    .limit(MAX_SEARCH_MESSAGES)
                    .findAll()

            matches
                .groupBy { message -> message.threadId }
                .mapNotNull { (threadId, messages) ->
                    realm
                        .where(Conversation::class.java)
                        .equalTo("id", threadId)
                        .notEqualTo("id", 0L)
                        .isNotNull("lastMessage")
                        .equalTo("blocked", false)
                        .isNotEmpty("recipients")
                        .findFirst()
                        ?.let { conversation -> conversation to messages }
                }
                .sortedByDescending { (_, messages) -> messages.size }
                .flatMap { (conversation, messages) ->
                    val header =
                        SearchItem.Header(
                            conversationId = conversation.id,
                            title = conversation.getTitle(),
                        )
                    val items =
                        messages.mapNotNull { message ->
                            val body =
                                when {
                                    message.body.isNotEmpty() -> message.body
                                    message.parts.isNotEmpty() ->
                                        message.parts.firstOrNull()?.text ?: ""
                                    else -> ""
                                }
                            body
                                .takeIf { it.isNotEmpty() }
                                ?.let {
                                    SearchItem.Message(
                                        messageId = message.id,
                                        conversationId = conversation.id,
                                        body = it,
                                        timestamp = message.date,
                                    )
                                }
                        }
                    listOf(header) + items
                }
        }

    override fun getBlockedConversations(): RealmResults<Conversation> =
        Realm.getDefaultInstance()
            .where(Conversation::class.java)
            .equalTo("blocked", true)
            .sort(arrayOf("lastMessage.date"), arrayOf(Sort.DESCENDING))
            .findAll()

    override fun getBlockedConversationsAsync(): RealmResults<Conversation> =
        Realm.getDefaultInstance()
            .where(Conversation::class.java)
            .equalTo("blocked", true)
            .sort(arrayOf("lastMessage.date"), arrayOf(Sort.DESCENDING))
            .findAllAsync()

    override fun getConversationAsync(threadId: Long): Conversation =
        Realm.getDefaultInstance()
            .where(Conversation::class.java)
            .equalTo("id", threadId)
            .findFirstAsync()

    override fun getConversation(threadId: Long) =
        Realm.getDefaultInstance()
            .apply { refresh() }
            .where(Conversation::class.java)
            .equalTo("id", threadId)
            .findFirst()

    override fun getUnseenIds(archived: Boolean) =
        ArrayList<Long>().apply {
            Realm.getDefaultInstance()
                .where(Conversation::class.java)
                .notEqualTo("id", 0L)
                .equalTo("archived", archived)
                .equalTo("blocked", false)
                .equalTo("lastMessage.seen", false)
                .sort(arrayOf("lastMessage.date"), arrayOf(Sort.DESCENDING))
                .findAllAsync()
                .forEach { conversation -> add(conversation.id) }
        }

    override fun getUnreadIds(archived: Boolean) =
        ArrayList<Long>().apply {
            Realm.getDefaultInstance()
                .where(Conversation::class.java)
                .notEqualTo("id", 0L)
                .equalTo("archived", archived)
                .equalTo("blocked", false)
                .equalTo("lastMessage.read", false)
                .sort(arrayOf("lastMessage.date"), arrayOf(Sort.DESCENDING))
                .findAllAsync()
                .forEach { conversation -> add(conversation.id) }
        }

    override fun getConversationAndLastSenderContactName(
        threadId: Long
    ): Pair<Conversation?, String?>? =
        Realm.getDefaultInstance()
            .apply { refresh() }
            .where(Conversation::class.java)
            .equalTo("id", threadId)
            .findFirst()
            ?.let { conversation ->
                val conversationLastSmsSender: String? =
                    conversation.recipients
                        .find { recipient ->
                            phoneNumberUtils.compare(
                                recipient.address,
                                conversation.lastMessage!!.address,
                            )
                        }
                        ?.contact
                        ?.name

                Pair(conversation, conversationLastSmsSender)
            }

    override fun getConversations(vararg threadIds: Long): RealmResults<Conversation> =
        Realm.getDefaultInstance().where(Conversation::class.java).anyOf("id", threadIds).findAll()

    override fun getUnmanagedConversations(): Observable<List<Conversation>> =
        Realm.getDefaultInstance().let { realm ->
            realm
                .where(Conversation::class.java)
                .sort("lastMessage.date", Sort.DESCENDING)
                .notEqualTo("id", 0L)
                .isNotNull("lastMessage")
                .equalTo("archived", false)
                .equalTo("blocked", false)
                .isNotEmpty("recipients")
                .limit(5)
                .findAllAsync()
                .asObservable()
                .filter { it.isLoaded }
                .filter { it.isValid }
                .map { realm.copyFromRealm(it) }
                .subscribeOn(AndroidSchedulers.mainThread())
                .observeOn(Schedulers.io())
        }

    override fun getRecipients(): RealmResults<Recipient> =
        Realm.getDefaultInstance().where(Recipient::class.java).findAll()

    override fun getUnmanagedRecipients(): Observable<List<Recipient>> =
        Realm.getDefaultInstance().let { realm ->
            realm
                .where(Recipient::class.java)
                .isNotNull("contact")
                .findAllAsync()
                .asObservable()
                .filter { it.isLoaded && it.isValid }
                .map { realm.copyFromRealm(it) }
                .subscribeOn(AndroidSchedulers.mainThread())
        }

    override fun getRecipient(recipientId: Long): Recipient? =
        Realm.getDefaultInstance()
            .where(Recipient::class.java)
            .equalTo("id", recipientId)
            .findFirst()

    override fun getConversation(recipient: String) = getConversation(listOf(recipient))

    override fun getConversation(recipients: Collection<String>): Conversation? =
        Realm.getDefaultInstance().use { realm ->
            realm.refresh()
            realm
                .where(Conversation::class.java)
                .findAll()
                .asSequence()
                .filter { conversation -> conversation.recipients.size == recipients.size }
                .find { conversation ->
                    conversation.recipients
                        .map { it.address }
                        .all { address ->
                            recipients.any { recipient ->
                                phoneNumberUtils.compare(recipient, address)
                            }
                        }
                }
                ?.let { realm.copyFromRealm(it) }
        }

    override fun getOrCreateConversation(threadId: Long) =
        tryOrNull(true) { getConversation(threadId) ?: createConversationFromCp(threadId) }

    override fun getOrCreateConversation(address: String) = getOrCreateConversation(listOf(address))

    override fun getOrCreateConversation(addresses: Collection<String>) =
        tryOrNull(true) {
            getConversation(addresses)
                ?: tryOrNull { TelephonyCompat.getOrCreateThreadId(context, addresses.toSet()) }
                    ?.takeIf { it != 0L }
                    ?.let { threadId ->
                        getOrCreateConversation(threadId)
                            ?: createConversationFromAddresses(threadId, addresses)
                    }
        }

    override fun saveDraft(threadId: Long, draft: String) =
        Realm.getDefaultInstance().use { realm ->
            realm.refresh()

            val conversation =
                realm.where(Conversation::class.java).equalTo("id", threadId).findFirst()

            realm.executeTransaction {
                conversation?.takeIf { it.isValid }?.draft = draft
                conversation?.takeIf { it.isValid }?.draftDate = System.currentTimeMillis()
            }
        }

    override fun updateConversations(vararg threadIds: Long) =
        Realm.getDefaultInstance().use { realm ->
            realm.refresh()

            threadIds.forEach { threadId ->
                val conversation =
                    realm.where(Conversation::class.java).equalTo("id", threadId).findFirst()
                        ?: return@forEach

                val message =
                    realm
                        .where(Message::class.java)
                        .equalTo("threadId", threadId)
                        .sort("date", Sort.DESCENDING)
                        .findFirst()

                realm.executeTransaction { conversation.lastMessage = message }
            }
        }

    override fun markArchived(vararg threadIds: Long) =
        Realm.getDefaultInstance().use { realm ->
            val conversations =
                realm.where(Conversation::class.java).anyOf("id", threadIds).findAll()

            realm.executeTransaction { conversations.forEach { it.archived = true } }
        }

    override fun markUnarchived(vararg threadIds: Long) =
        Realm.getDefaultInstance().use { realm ->
            val conversations =
                realm.where(Conversation::class.java).anyOf("id", threadIds).findAll()

            realm.executeTransaction { conversations.forEach { it.archived = false } }
        }

    override fun markPinned(vararg threadIds: Long) =
        Realm.getDefaultInstance().use { realm ->
            val conversations =
                realm.where(Conversation::class.java).anyOf("id", threadIds).findAll()

            realm.executeTransaction { conversations.forEach { it.pinned = true } }
        }

    override fun markUnpinned(vararg threadIds: Long) =
        Realm.getDefaultInstance().use { realm ->
            val conversations =
                realm.where(Conversation::class.java).anyOf("id", threadIds).findAll()

            realm.executeTransaction { conversations.forEach { it.pinned = false } }
        }

    override fun markBlocked(
        threadIds: Collection<Long>,
        blockingClient: Int,
        blockReason: String?,
    ) =
        Realm.getDefaultInstance().use { realm ->
            val conversations =
                realm
                    .where(Conversation::class.java)
                    .anyOf("id", threadIds.toLongArray())
                    .equalTo("blocked", false)
                    .findAll()

            realm.executeTransaction {
                conversations.forEach { conversation ->
                    conversation.blocked = true
                    conversation.blockingClient = blockingClient
                    conversation.blockReason = blockReason
                }
            }
        }

    override fun markUnblocked(vararg threadIds: Long) =
        Realm.getDefaultInstance().use { realm ->
            val conversations =
                realm.where(Conversation::class.java).anyOf("id", threadIds).findAll()

            realm.executeTransaction {
                conversations.forEach { conversation ->
                    conversation.blocked = false
                    conversation.blockingClient = null
                    conversation.blockReason = null
                }
            }
        }

    override fun deleteConversations(vararg threadIds: Long) {
        Realm.getDefaultInstance().use { realm ->
            val conversation =
                realm.where(Conversation::class.java).anyOf("id", threadIds).findAll()
            val messages = realm.where(Message::class.java).anyOf("threadId", threadIds).findAll()

            realm.executeTransaction {
                conversation.deleteAllFromRealm()
                messages.deleteAllFromRealm()
            }
        }

        threadIds.forEach {
            context.contentResolver.delete(
                ContentUris.withAppendedId(TelephonyCompat.THREADS_CONTENT_URI, it),
                null,
                null,
            )
        }
    }

    /**
     * Returns a [Conversation] from the system SMS ContentProvider, based on the [threadId]
     *
     * It should be noted that even if we have a valid [threadId], that does not guarantee that we
     * can return a [Conversation]. On some devices, the ContentProvider won't return the
     * conversation unless it contains at least 1 message
     */
    private fun createConversationFromCp(threadId: Long) =
        tryOrNull(true) {
            cursorToConversation
                .getConversationsCursor()
                ?.map(cursorToConversation::map)
                ?.firstOrNull { conversation -> conversation.id == threadId }
                ?.also { conversation ->
                    Realm.getDefaultInstance().use { realm ->
                        val realmContacts = realm.where(Contact::class.java).findAll()

                        // match recipients from provider to recipients in realm
                        val matchedRecipients =
                            conversation.recipients
                                .mapNotNull { recipient ->
                                    // map the recipient cursor to a list of recipients
                                    cursorToRecipient.getRecipientCursor(recipient.id)?.use { cursor
                                        ->
                                        cursor.map { cursorToRecipient.map(it) }
                                    }
                                }
                                .flatten()
                                .map { recipient ->
                                    recipient.apply {
                                        contact =
                                            realmContacts.firstOrNull { realmContact ->
                                                realmContact.numbers.any {
                                                    phoneNumberUtils.compare(it.address, address)
                                                }
                                            }
                                    }
                                }

                        conversation.apply {
                            recipients.clear()
                            recipients.addAll(matchedRecipients)
                            lastMessage =
                                realm
                                    .where(Message::class.java)
                                    .equalTo("threadId", threadId)
                                    .sort("date", Sort.DESCENDING)
                                    .findFirst()
                        }

                        realm.executeTransaction { it.insertOrUpdate(conversation) }
                    }
                }
        }

    /**
     * Fallback for when the content provider doesn't list the conversation (e.g. new thread with no
     * messages yet). Creates the Conversation directly in Realm using the known addresses and
     * canonical address IDs from the telephony provider.
     */
    private fun createConversationFromAddresses(
        threadId: Long,
        addresses: Collection<String>,
    ): Conversation? =
        tryOrNull(true) {
            // Query all canonical addresses from the telephony provider
            val allCanonicalRecipients =
                cursorToRecipient.getRecipientCursor()?.use { cursor ->
                    cursor.map { cursorToRecipient.map(it) }
                } ?: emptyList()

            Realm.getDefaultInstance().use { realm ->
                realm.refresh()
                val realmContacts = realm.where(Contact::class.java).findAll()

                val recipients =
                    addresses.map { address ->
                        // Find the canonical address entry that getOrCreateThreadId created
                        val canonical =
                            allCanonicalRecipients.firstOrNull { recipient ->
                                phoneNumberUtils.compare(recipient.address, address)
                            }

                        Recipient(
                                id = canonical?.id ?: 0L,
                                address = canonical?.address ?: address,
                                lastUpdate = System.currentTimeMillis(),
                            )
                            .apply {
                                contact =
                                    realmContacts.firstOrNull { realmContact ->
                                        realmContact.numbers.any {
                                            phoneNumberUtils.compare(it.address, address)
                                        }
                                    }
                            }
                    }

                val conversation =
                    Conversation().apply {
                        id = threadId
                        this.recipients.clear()
                        this.recipients.addAll(recipients)
                    }

                realm.executeTransaction { it.insertOrUpdate(conversation) }
            }

            getConversation(threadId)
        }

    companion object {
        const val MAX_SEARCH_MESSAGES = 500L
    }
}
