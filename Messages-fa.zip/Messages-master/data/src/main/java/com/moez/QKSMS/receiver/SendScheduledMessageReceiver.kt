/*
 * SPDX-FileCopyrightText: 2017 Moez Bhatti <moez.bhatti@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import dagger.android.AndroidInjection
import javax.inject.Inject
import ir.pmessages.app.interactor.SendScheduledMessage
import ir.pmessages.app.repository.MessageRepository

class SendScheduledMessageReceiver : BroadcastReceiver() {

    @Inject lateinit var messageRepo: MessageRepository
    @Inject lateinit var sendScheduledMessage: SendScheduledMessage

    override fun onReceive(context: Context, intent: Intent) {
        AndroidInjection.inject(this, context)

        intent
            .getLongExtra("id", -1L)
            .takeIf { it >= 0 }
            ?.let { id ->
                val result = goAsync()
                sendScheduledMessage.execute(id) { result.finish() }
            }
    }
}
