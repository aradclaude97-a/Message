/*
 * SPDX-FileCopyrightText: Saalim Quadri <danascape@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.receiver

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.preference.PreferenceManager
import android.provider.Telephony
import androidx.core.content.edit
import dagger.android.AndroidInjection
import io.realm.Realm
import java.io.ByteArrayOutputStream
import java.io.File
import ir.pmessages.app.interactor.CancelDelayedMessage
import ir.pmessages.app.interactor.DeleteMessages
import ir.pmessages.app.interactor.SendDelayedMessageNow
import ir.pmessages.app.interactor.SendMessage
import ir.pmessages.app.model.Attachment
import ir.pmessages.app.model.Message
import timber.log.Timber

class TestMmsPushReceiver : MmsReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            ACTION_SEND -> return send(context, intent)
            ACTION_DOWNLOAD -> return download(context, intent)
            ACTION_SET_PREF -> return setPref(context, intent)
            ACTION_BLOCK -> return block(context, intent)
            ACTION_DELETE -> return delete(context, intent)
            ACTION_RETRY -> return retry(context, intent)
            ACTION_SMS_RESULT -> return smsResult(context, intent)
            ACTION_SMS_DELAYED -> return smsDelayed(context, intent)
            ACTION_SMS_NOTIFICATION_RETRY -> return smsNotificationRetry(context, intent)
            ACTION_SMS_DUMP -> return smsDump(context, intent)
            ACTION_SMS_RECEIVE -> return smsReceive(context, intent)
        }

        val pdu = intent.getStringExtra(EXTRA_PDU)?.hexToBytes()
        if (pdu == null) {
            Timber.w("No PDU to deliver")
            return
        }

        Timber.v("Delivering a test MMS notification of ${pdu.size} bytes")
        val push =
            Intent(Telephony.Sms.Intents.WAP_PUSH_DELIVER_ACTION)
                .setType("application/vnd.wap.mms-message")
                .putExtra("data", pdu)
        if (intent.hasExtra(EXTRA_SUBSCRIPTION)) {
            push.putExtra(EXTRA_SUBSCRIPTION, intent.getIntExtra(EXTRA_SUBSCRIPTION, -1))
        }
        super.onReceive(context, push)
    }

    private fun send(context: Context, intent: Intent) {
        val addresses = intent.getStringExtra("to")?.split(',')?.filter { it.isNotBlank() }
        if (addresses.isNullOrEmpty()) {
            Timber.w("No recipients to send to")
            return
        }

        val sender = RemoteMessagingReceiver().also { AndroidInjection.inject(it, context) }
        val kinds =
            intent.getStringExtra("attach")?.split(',')?.filter { it.isNotBlank() }.orEmpty() +
                listOfNotNull("png".takeIf { intent.getBooleanExtra("image", false) })
        val attachments = kinds.mapIndexed { index, kind -> testAttachment(context, kind, index) }
        val recipients =
            if (intent.getBooleanExtra("individually", false)) addresses.map(::listOf)
            else listOf(addresses)
        val params =
            recipients.map { to ->
                SendMessage.Params(
                    subId = intent.getIntExtra(EXTRA_SUBSCRIPTION, -1),
                    threadId = 0,
                    addresses = to,
                    body = intent.getStringExtra("text").orEmpty(),
                    attachments = attachments,
                    delay = intent.getIntExtra("delay", 0),
                )
            }

        Timber.v("Sending a test message to $addresses")
        val pendingResult = goAsync()
        Thread {
                try {
                    params.forEach {
                        sender.sendMessage.buildObservable(it).blockingSubscribe({}, Timber::w)
                    }
                } finally {
                    pendingResult.finish()
                }
            }
            .start()
    }

    private fun download(context: Context, intent: Intent) {
        val uri = intent.getStringExtra("uri")?.let(Uri::parse) ?: return
        val repo =
            RemoteMessagingReceiver().also { AndroidInjection.inject(it, context) }.messageRepo
        val pendingResult = goAsync()
        Thread {
                try {
                    repo.downloadMms(uri, intent.getIntExtra(EXTRA_SUBSCRIPTION, -1), false)
                } finally {
                    pendingResult.finish()
                }
            }
            .start()
    }

    private fun setPref(context: Context, intent: Intent) {
        val key = intent.getStringExtra("key") ?: return
        PreferenceManager.getDefaultSharedPreferences(context).edit {
            if (intent.hasExtra("value")) putBoolean(key, intent.getBooleanExtra("value", false))
            else remove(key)
        }
    }

    private fun testAttachment(context: Context, kind: String, index: Int): Attachment {
        fun bitmap(size: Int, format: Bitmap.CompressFormat, color: Int) =
            ByteArrayOutputStream()
                .also { out ->
                    Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
                        .apply { eraseColor(color) }
                        .compress(format, 100, out)
                }
                .toByteArray()

        val (extension, bytes) =
            when (kind) {
                "jpeg" -> "jpg" to bitmap(64, Bitmap.CompressFormat.JPEG, Color.BLUE)
                "bigimage" -> "jpg" to noisyJpeg(2000)
                "gif" -> "gif" to GIF
                "video" -> "mp4" to MP4
                "audio" -> "amr" to AMR
                "vcard" ->
                    "vcf" to
                        "BEGIN:VCARD\r\nVERSION:3.0\r\nFN:Test\r\nTEL:+15559876543\r\nEND:VCARD\r\n"
                            .toByteArray()
                "pdf" -> "pdf" to "%PDF-1.4\n%%EOF\n".toByteArray()
                "bigfile" -> "bin" to ByteArray(2 * 1024 * 1024) { it.toByte() }
                else -> "png" to bitmap(64, Bitmap.CompressFormat.PNG, Color.MAGENTA)
            }
        val file = File(context.cacheDir, "test-attachment-$index.$extension")
        file.writeBytes(bytes)
        return Attachment(context, Uri.fromFile(file))
    }

    private fun noisyJpeg(size: Int): ByteArray {
        val random = java.util.Random(1)
        val pixels = IntArray(size * size) { random.nextInt() or 0xFF000000.toInt() }
        val bitmap = Bitmap.createBitmap(pixels, size, size, Bitmap.Config.ARGB_8888)
        return ByteArrayOutputStream()
            .also { bitmap.compress(Bitmap.CompressFormat.JPEG, 100, it) }
            .toByteArray()
    }

    private fun block(context: Context, intent: Intent) {
        val address = intent.getStringExtra("address") ?: return
        val client =
            BlockThreadReceiver().also { AndroidInjection.inject(it, context) }.blockingClient
        runInBackground {
            when (intent.getBooleanExtra("unblock", false)) {
                true -> client.unblock(listOf(address)).blockingAwait()
                false -> client.block(listOf(address)).blockingAwait()
            }
        }
    }

    private fun delete(context: Context, intent: Intent) {
        val remote = RemoteMessagingReceiver().also { AndroidInjection.inject(it, context) }
        val deleteMessages =
            DeleteMessagesReceiver().also { AndroidInjection.inject(it, context) }.deleteMessages
        val thread = intent.getLongExtra("thread", -1)
        val message = intent.getStringExtra("uri")?.let(Uri::parse)?.let(::findMessage)
        runInBackground {
            when {
                thread != -1L -> remote.conversationRepo.deleteConversations(thread)
                message != null ->
                    deleteMessages
                        .buildObservable(
                            DeleteMessages.Params(listOf(message.first), message.second)
                        )
                        .blockingSubscribe({}, Timber::w)
            }
        }
    }

    private fun smsResult(context: Context, intent: Intent) {
        val message = intent.getStringExtra("uri")?.let(Uri::parse)?.let(::findMessage) ?: return
        val result =
            when (intent.getStringExtra("kind")) {
                "delivered" ->
                    Intent(context, SmsDeliveredReceiver::class.java)
                        .putExtra("id", message.first)
                        .putExtra("pdu", intent.getStringExtra("pdu")?.hexToBytes())
                        .putExtra("format", intent.getStringExtra("format") ?: "3gpp")

                else ->
                    Intent(context, SmsSentReceiver::class.java)
                        .putExtra(SmsSentParts.EXTRA_ID, message.first)
                        .putExtra(SmsSentParts.EXTRA_ATTEMPT, intent.getLongExtra("attempt", 1))
                        .putExtra(SmsSentParts.EXTRA_PART, intent.getIntExtra("part", 0))
                        .putExtra(SmsSentParts.EXTRA_PARTS, intent.getIntExtra("parts", 1))
                        .putExtra("errorCode", intent.getIntExtra("errorCode", -1))
            }
        val code = intent.getIntExtra("result", android.app.Activity.RESULT_OK)
        context.sendOrderedBroadcast(result, null, null, null, code, null, null)
    }

    private fun smsDelayed(context: Context, intent: Intent) {
        val message = intent.getStringExtra("uri")?.let(Uri::parse)?.let(::findMessage) ?: return
        val remote = RemoteMessagingReceiver().also { AndroidInjection.inject(it, context) }
        runInBackground {
            when (intent.getStringExtra("op")) {
                "cancel" ->
                    CancelDelayedMessage(remote.conversationRepo, remote.messageRepo)
                        .buildObservable(CancelDelayedMessage.Params(message.first, message.second))
                        .blockingSubscribe({}, Timber::w)

                else ->
                    SendDelayedMessageNow(remote.conversationRepo, remote.messageRepo)
                        .buildObservable(
                            SendDelayedMessageNow.Params(message.first, message.second)
                        )
                        .blockingSubscribe({}, Timber::w)
            }
        }
    }

    private fun smsNotificationRetry(context: Context, intent: Intent) {
        val message = intent.getStringExtra("uri")?.let(Uri::parse)?.let(::findMessage) ?: return
        context.sendBroadcast(
            Intent(context, SendSmsReceiver::class.java)
                .setAction(SendSmsReceiver.ACTION_RETRY)
                .putExtra("id", message.first)
        )
    }

    private fun smsDump(context: Context, intent: Intent) {
        val columns =
            arrayOf(
                "_id",
                "thread_id",
                "address",
                "type",
                "status",
                "error_code",
                "read",
                "seen",
                "protocol",
                "reply_path_present",
                "service_center",
                "date",
                "date_sent",
                "body",
            )
        val rows =
            context.contentResolver
                .query(Telephony.Sms.CONTENT_URI, columns, null, null, "_id DESC")
                ?.use { cursor ->
                    generateSequence { cursor.takeIf { it.moveToNext() } }
                        .take(intent.getIntExtra("limit", 50))
                        .map { row ->
                            columns.indices.joinToString("\t") { i ->
                                row.getString(i).orEmpty().replace('\t', ' ').replace('\n', ' ')
                            }
                        }
                        .toList()
                }
                .orEmpty()
        setResult(0, rows.joinToString("\n"), null)
    }

    private fun smsReceive(context: Context, intent: Intent) {
        val format = intent.getStringExtra("format") ?: "3gpp"
        val parts =
            intent.getStringExtra("pdus")?.split(',')?.mapNotNull { hex ->
                hex.hexToBytes()?.let { android.telephony.SmsMessage.createFromPdu(it, format) }
            }
        if (parts.isNullOrEmpty()) {
            Timber.w("No PDUs to receive")
            return
        }
        val receiver = SmsReceiver().also { AndroidInjection.inject(it, context) }
        runInBackground {
            receiver.receive(context, parts, intent.getIntExtra(EXTRA_SUBSCRIPTION, -1))
        }
    }

    private fun retry(context: Context, intent: Intent) {
        val message = intent.getStringExtra("uri")?.let(Uri::parse)?.let(::findMessage) ?: return
        val retrySending =
            SendSmsReceiver().also { AndroidInjection.inject(it, context) }.retrySending
        runInBackground {
            retrySending.buildObservable(message.first).blockingSubscribe({}, Timber::w)
        }
    }

    private fun findMessage(uri: Uri): Pair<Long, Long>? =
        Realm.getDefaultInstance().use { realm ->
            realm.refresh()
            realm
                .where(Message::class.java)
                .equalTo("type", if (uri.authority == "sms") "sms" else "mms")
                .equalTo("contentId", ContentUris.parseId(uri))
                .findFirst()
                ?.let { it.id to it.threadId }
        }

    private fun runInBackground(work: () -> Unit) {
        val pendingResult = goAsync()
        Thread {
                try {
                    work()
                } catch (e: Exception) {
                    Timber.w(e)
                } finally {
                    pendingResult.finish()
                }
            }
            .start()
    }

    override fun inject(context: Context) {
        val injected = MmsReceiver()
        AndroidInjection.inject(injected, context)
        mmsDownloadPolicy = injected.mmsDownloadPolicy
        receiveMms = injected.receiveMms
    }

    private fun String.hexToBytes(): ByteArray? =
        takeIf { it.length % 2 == 0 }
            ?.chunked(2)
            ?.map { it.toIntOrNull(16)?.toByte() ?: return null }
            ?.toByteArray()

    companion object {
        private const val ACTION_SEND = "ir.pmessages.app.TEST_MMS_SEND"
        private const val ACTION_DOWNLOAD = "ir.pmessages.app.TEST_MMS_DOWNLOAD"
        private const val ACTION_SET_PREF = "ir.pmessages.app.TEST_SET_PREF"
        private const val ACTION_BLOCK = "ir.pmessages.app.TEST_BLOCK"
        private const val ACTION_DELETE = "ir.pmessages.app.TEST_DELETE"
        private const val ACTION_RETRY = "ir.pmessages.app.TEST_RETRY"
        private const val ACTION_SMS_RESULT = "ir.pmessages.app.TEST_SMS_RESULT"
        private const val ACTION_SMS_DELAYED = "ir.pmessages.app.TEST_SMS_DELAYED"
        private const val ACTION_SMS_DUMP = "ir.pmessages.app.TEST_SMS_DUMP"
        private const val ACTION_SMS_RECEIVE = "ir.pmessages.app.TEST_SMS_RECEIVE"
        private const val ACTION_SMS_NOTIFICATION_RETRY =
            "ir.pmessages.app.TEST_SMS_NOTIFICATION_RETRY"

        private val GIF =
            byteArrayOf(
                0x47,
                0x49,
                0x46,
                0x38,
                0x39,
                0x61,
                1,
                0,
                1,
                0,
                0x80.toByte(),
                0,
                0,
                0,
                0,
                0,
                0xFF.toByte(),
                0xFF.toByte(),
                0xFF.toByte(),
                0x21,
                0xF9.toByte(),
                4,
                1,
                0,
                0,
                0,
                0,
                0x2C,
                0,
                0,
                0,
                0,
                1,
                0,
                1,
                0,
                0,
                2,
                2,
                0x44,
                1,
                0,
                0x3B,
            )
        private val MP4 =
            "\u0000\u0000\u0000\u0018ftypmp42\u0000\u0000\u0000\u0000mp42isom".toByteArray()
        private val AMR = "#!AMR\n".toByteArray() + ByteArray(160) { if (it % 32 == 0) 0x3C else 0 }
        private const val EXTRA_PDU = "pdu"
        private const val EXTRA_SUBSCRIPTION = "subscription"
    }
}
