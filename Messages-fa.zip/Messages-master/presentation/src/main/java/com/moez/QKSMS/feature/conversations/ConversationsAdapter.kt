/*
 * SPDX-FileCopyrightText: 2017 Moez Bhatti <moez.bhatti@gmail.com>
 * SPDX-FileCopyrightText: Saalim Quadri <danascape@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.feature.conversations

import android.content.Context
import android.graphics.Typeface
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.text.buildSpannedString
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.moez.QKSMS.common.widget.FastScrollerView
import io.reactivex.disposables.CompositeDisposable
import javax.inject.Inject
import ir.pmessages.app.R
import ir.pmessages.app.common.Navigator
import ir.pmessages.app.common.base.QkRealmAdapter
import ir.pmessages.app.common.base.QkViewHolder
import ir.pmessages.app.common.util.Colors
import ir.pmessages.app.common.util.DateFormatter
import ir.pmessages.app.common.util.extensions.resolveThemeColor
import ir.pmessages.app.databinding.ConversationListItemBinding
import ir.pmessages.app.model.Conversation
import ir.pmessages.app.repository.ScheduledMessageRepository
import ir.pmessages.app.util.PhoneNumberUtils

class ConversationsAdapter
@Inject
constructor(
    private val colors: Colors,
    private val context: Context,
    private val dateFormatter: DateFormatter,
    private val scheduledMessageRepo: ScheduledMessageRepository,
    private val navigator: Navigator,
    private val phoneNumberUtils: PhoneNumberUtils,
) : QkRealmAdapter<Conversation, QkViewHolder>(), FastScrollerView.SectionTitleProvider {
    private val disposables = CompositeDisposable()

    init {
        // This is how we access the threadId for the swipe actions
        setHasStableIds(true)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): QkViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val binding = ConversationListItemBinding.inflate(layoutInflater, parent, false)

        binding.title.setTypeface(binding.title.typeface, Typeface.BOLD)

        if (viewType == 1) {
            val textColorPrimary = parent.context.resolveThemeColor(android.R.attr.textColorPrimary)

            binding.snippet.setTypeface(binding.snippet.typeface, Typeface.BOLD)
            binding.snippet.setTextColor(textColorPrimary)
            binding.snippet.maxLines = 5

            binding.unread.isVisible = true

            binding.date.setTypeface(binding.date.typeface, Typeface.BOLD)
            binding.date.setTextColor(textColorPrimary)
        }

        return QkViewHolder(binding.root).apply {
            binding.root.setOnClickListener {
                val conversation = getItem(adapterPosition) ?: return@setOnClickListener
                when (toggleSelection(conversation.id, false)) {
                    true -> binding.root.isActivated = isSelected(conversation.id)
                    false -> navigator.showConversation(conversation.id)
                }
            }
            binding.root.setOnLongClickListener {
                val conversation = getItem(adapterPosition) ?: return@setOnLongClickListener true
                toggleSelection(conversation.id)
                binding.root.isActivated = isSelected(conversation.id)
                true
            }
        }
    }

    override fun onBindViewHolder(holder: QkViewHolder, position: Int) {
        val conversation = getItem(position) ?: return
        val binding = ConversationListItemBinding.bind(holder.containerView)

        // If the last message wasn't incoming, then the colour doesn't really matter anyway
        val lastMessage = conversation.lastMessage
        val recipient =
            when {
                conversation.recipients.size == 1 || lastMessage == null ->
                    conversation.recipients.firstOrNull()
                else ->
                    conversation.recipients.find { recipient ->
                        phoneNumberUtils.compare(recipient.address, lastMessage.address)
                    }
            }
        val theme = colors.theme(recipient).theme

        holder.containerView.isActivated = isSelected(conversation.id)

        binding.avatars.recipients = conversation.recipients
        binding.title.collapseEnabled = conversation.recipients.size > 1
        binding.title.text = buildSpannedString { append(conversation.getTitle()) }
        binding.date.text =
            conversation.date.takeIf { it > 0 }?.let(dateFormatter::getConversationTimestamp)
        binding.snippet.text =
            when {
                conversation.draft.isNotEmpty() ->
                    context.getString(R.string.main_sender_draft, conversation.draft)
                conversation.me -> context.getString(R.string.main_sender_you, conversation.snippet)
                else -> conversation.snippet
            }

        // Make the preview in italics if draft
        if (conversation.draft.isNotEmpty()) binding.snippet.setTypeface(null, Typeface.ITALIC)

        // Get Scheduled Messages
        val disposable =
            scheduledMessageRepo
                .getScheduledMessagesForConversation(conversation.id)
                .asFlowable()
                .toObservable()
                .subscribe { messages -> binding.scheduled.isVisible = messages.isNotEmpty() }
        disposables.add(disposable)

        binding.pinned.isVisible = conversation.pinned
    }

    override fun getItemId(position: Int): Long {
        return getItem(position)?.id ?: -1
    }

    override fun getItemViewType(position: Int): Int {
        return if (getItem(position)?.unread == false) 0 else 1
    }

    override fun onDetachedFromRecyclerView(recyclerView: RecyclerView) {
        super.onDetachedFromRecyclerView(recyclerView)
        disposables.clear()
    }

    /** Public method to start selection mode by selecting the first item */
    fun startSelectionMode() {
        if (itemCount > 0) {
            val firstId = getItemId(0)
            toggleSelection(firstId, force = true)
            notifyItemChanged(0)
        }
    }

    override fun getSectionTitle(position: Int): String {
        val conversation = getItem(position) ?: return ""
        val timestamp = conversation.date
        return if (timestamp > 0) {
            dateFormatter.getConversationTimestamp(timestamp) ?: ""
        } else {
            ""
        }
    }
}
