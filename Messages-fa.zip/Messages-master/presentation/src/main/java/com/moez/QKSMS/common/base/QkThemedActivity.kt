/*
 * SPDX-FileCopyrightText: 2018 Moez Bhatti <moez.bhatti@gmail.com>
 * SPDX-FileCopyrightText: Saalim Quadri <danascape@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.common.base

import android.app.ActivityManager
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.widget.Toolbar
import androidx.core.view.iterator
import androidx.lifecycle.Lifecycle
import androidx.viewbinding.ViewBinding
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDispose
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.rxkotlin.Observables
import io.reactivex.subjects.BehaviorSubject
import io.reactivex.subjects.Subject
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import ir.pmessages.app.R
import ir.pmessages.app.app.utils.AppUtil.applyEdgeToEdgeInsets
import ir.pmessages.app.common.util.Colors
import ir.pmessages.app.common.util.extensions.resolveThemeBoolean
import ir.pmessages.app.common.util.extensions.resolveThemeColor
import ir.pmessages.app.extensions.Optional
import ir.pmessages.app.extensions.asObservable
import ir.pmessages.app.extensions.mapNotNull
import ir.pmessages.app.repository.ConversationRepository
import ir.pmessages.app.repository.MessageRepository
import ir.pmessages.app.util.PhoneNumberUtils

/**
 * Base activity that automatically applies any necessary theme theme settings and colors
 *
 * In most cases, this should be used instead of the base QkActivity, except for when an activity
 * does not depend on the theme
 */
abstract class QkThemedActivity<Vb : ViewBinding>(inflate: (LayoutInflater) -> Vb) :
    QkActivity<Vb>(inflate) {

    @Inject lateinit var colors: Colors

    @Inject lateinit var conversationRepo: ConversationRepository

    @Inject lateinit var messageRepo: MessageRepository

    @Inject lateinit var phoneNumberUtils: PhoneNumberUtils

    val toolbarView: Toolbar?
        get() = findViewById(R.id.toolbar)

    /**
     * In case the activity should be themed for a specific conversation, the selected conversation
     * can be changed by pushing the threadId to this subject
     */
    val threadId: Subject<Long> = BehaviorSubject.createDefault(0)

    /**
     * Switch the theme if the threadId changes Set it based on the latest message in the
     * conversation
     */
    val theme: Observable<Colors.Theme> =
        threadId
            .distinctUntilChanged()
            .switchMap { threadId ->
                val conversation = conversationRepo.getConversation(threadId)
                when {
                    conversation == null -> Observable.just(Optional(null))

                    conversation.recipients.size == 1 ->
                        Observable.just(Optional(conversation.recipients.first()))

                    else ->
                        messageRepo
                            .getLastIncomingMessage(conversation.id)
                            .asObservable()
                            .mapNotNull { messages -> messages.firstOrNull() }
                            .distinctUntilChanged { message -> message.address }
                            .mapNotNull { message ->
                                conversation.recipients.find { recipient ->
                                    phoneNumberUtils.compare(recipient.address, message.address)
                                }
                            }
                            .map { recipient -> Optional(recipient) }
                            .startWith(Optional(conversation.recipients.firstOrNull()))
                            .distinctUntilChanged()
                }
            }
            .switchMap { colors.themeObservable(it.value) }

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(getActivityThemeRes())
        super.onCreate(savedInstanceState)

        // When certain preferences change, we need to recreate the activity
        val triggers = listOf(prefs.nightMode, prefs.night, prefs.textSize, prefs.systemFont)
        Observable.merge(triggers.map { it.asObservable().skip(1) })
            .debounce(400, TimeUnit.MILLISECONDS)
            .observeOn(AndroidSchedulers.mainThread())
            .autoDispose(scope())
            .subscribe { recreate() }

        // Draw behind the system bars on every version, as Android 15 and later always do
        if (!resolveThemeBoolean(android.R.attr.windowIsFloating)) {
            val bars =
                when (resolveThemeBoolean(R.attr.isLightTheme)) {
                    true -> SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
                    false -> SystemBarStyle.dark(Color.TRANSPARENT)
                }
            enableEdgeToEdge(bars, bars)
            applyEdgeToEdgeInsets(barsStyled = true)
        }

        // Set the color for the recent apps title
        val toolbarColor = resolveThemeColor(android.R.attr.colorBackground)
        val icon = BitmapFactory.decodeResource(resources, R.mipmap.ic_launcher)
        val taskDesc =
            ActivityManager.TaskDescription(getString(R.string.app_name), icon, toolbarColor)
        setTaskDescription(taskDesc)
    }

    override fun onPostCreate(savedInstanceState: Bundle?) {
        super.onPostCreate(savedInstanceState)

        // Set the color for the overflow and navigation icon
        val textSecondary = resolveThemeColor(android.R.attr.textColorSecondary)
        toolbarView?.overflowIcon = toolbarView?.overflowIcon?.apply { setTint(textSecondary) }

        // Update the colours of the menu items
        Observables.combineLatest(menu, theme) { menu, theme ->
                menu.iterator().forEach { menuItem ->
                    val tint =
                        when (menuItem.itemId) {
                            in getColoredMenuItems() -> theme.theme
                            else -> textSecondary
                        }

                    menuItem.icon = menuItem.icon?.apply { setTint(tint) }
                }
            }
            .autoDispose(scope(Lifecycle.Event.ON_DESTROY))
            .subscribe()
    }

    open fun getColoredMenuItems(): List<Int> {
        return listOf()
    }

    /** This can be overridden in case an activity does not want to use the default themes */
    open fun getActivityThemeRes(): Int = R.style.AppTheme
}
