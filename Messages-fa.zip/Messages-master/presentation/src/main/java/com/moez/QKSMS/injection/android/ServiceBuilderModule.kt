/*
 * SPDX-FileCopyrightText: 2017 Moez Bhatti <moez.bhatti@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.injection.android

import dagger.Module
import dagger.android.ContributesAndroidInjector
import ir.pmessages.app.feature.backup.RestoreBackupService
import ir.pmessages.app.injection.scope.ActivityScope
import ir.pmessages.app.receiver.SendSmsReceiver
import ir.pmessages.app.service.AutoDeleteService
import ir.pmessages.app.service.HeadlessSmsSendService

@Module
abstract class ServiceBuilderModule {

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindAutoDeleteService(): AutoDeleteService

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindHeadlessSmsSendService(): HeadlessSmsSendService

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindRestoreBackupService(): RestoreBackupService

    @ActivityScope @ContributesAndroidInjector() abstract fun bindSendSmsReceiver(): SendSmsReceiver
}
