/*
 * SPDX-FileCopyrightText: 2018 Moez Bhatti <moez.bhatti@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.feature.compose.part

import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import ir.pmessages.app.common.base.QkViewHolder
import ir.pmessages.app.common.util.Colors
import ir.pmessages.app.model.Message
import ir.pmessages.app.model.MmsPart

abstract class PartBinder {

    val clicks: Subject<Long> = PublishSubject.create()

    abstract val partLayout: Int

    abstract var theme: Colors.Theme

    abstract fun canBindPart(part: MmsPart): Boolean

    abstract fun bindPart(
        holder: QkViewHolder,
        part: MmsPart,
        message: Message,
        canGroupWithPrevious: Boolean,
        canGroupWithNext: Boolean,
    )
}
