/*
 * SPDX-FileCopyrightText: 2019 Moez Bhatti <moez.bhatti@gmail.com>
 * SPDX-FileCopyrightText: Saalim Quadri <danascape@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.feature.blocking.messages

import android.content.Context
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import javax.inject.Inject
import ir.pmessages.app.R
import ir.pmessages.app.common.base.QkController
import ir.pmessages.app.common.util.Colors
import ir.pmessages.app.feature.blocking.BlockingDialog
import ir.pmessages.app.injection.appComponent

class BlockedMessagesController :
    QkController<BlockedMessagesView, BlockedMessagesState, BlockedMessagesPresenter>(),
    BlockedMessagesView {

    override val menuReadyIntent: Subject<Unit> = PublishSubject.create()
    override val optionsItemIntent: Subject<Int> = PublishSubject.create()
    override val conversationClicks by lazy { blockedMessagesAdapter.clicks }
    override val selectionChanges by lazy { blockedMessagesAdapter.selectionChanges }
    override val confirmDeleteIntent: Subject<List<Long>> = PublishSubject.create()
    override val backClicked: Subject<Unit> = PublishSubject.create()

    @Inject lateinit var blockedMessagesAdapter: BlockedMessagesAdapter
    @Inject lateinit var blockingDialog: BlockingDialog
    @Inject lateinit var colors: Colors
    @Inject lateinit var context: Context
    @Inject override lateinit var presenter: BlockedMessagesPresenter

    private lateinit var conversations: RecyclerView
    private lateinit var empty: TextView

    init {
        appComponent.inject(this)
        retainViewMode = RetainViewMode.RETAIN_DETACH
        layoutRes = R.layout.blocked_messages_controller
    }

    override fun onViewCreated() {
        super.onViewCreated()

        val view = containerView ?: return

        conversations = view.findViewById(R.id.conversations)
        empty = view.findViewById(R.id.empty)

        blockedMessagesAdapter.emptyView = empty
        conversations.adapter = blockedMessagesAdapter
    }

    override fun onAttach(view: View) {
        super.onAttach(view)
        presenter.bindIntents(this)
        setTitle(R.string.blocked_messages_title)
        showBackButton(true)
        setHasOptionsMenu(true)
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        super.onCreateOptionsMenu(menu, inflater)
        inflater.inflate(R.menu.blocked_messages, menu)
        menuReadyIntent.onNext(Unit)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        optionsItemIntent.onNext(item.itemId)
        return true
    }

    override fun handleBack(): Boolean {
        backClicked.onNext(Unit)
        return true
    }

    override fun render(state: BlockedMessagesState) {
        blockedMessagesAdapter.updateData(state.data)

        themedActivity?.toolbarView?.menu?.findItem(R.id.block)?.isVisible = state.selected > 0
        themedActivity?.toolbarView?.menu?.findItem(R.id.delete)?.isVisible = state.selected > 0

        setTitle(
            when (state.selected) {
                0 -> context.getString(R.string.blocked_messages_title)
                else -> context.getString(R.string.main_title_selected, state.selected)
            }
        )
    }

    override fun clearSelection() = blockedMessagesAdapter.clearSelection()

    override fun showBlockingDialog(conversations: List<Long>, block: Boolean) {
        blockingDialog.show(activity!! as ComponentActivity, conversations, block)
    }

    override fun showDeleteDialog(conversations: List<Long>) {
        val count = conversations.size
        val dialog =
            AlertDialog.Builder(activity!!, R.style.AppThemeDialog)
                .setTitle(R.string.dialog_delete_title)
                .setMessage(
                    resources?.getQuantityString(R.plurals.dialog_delete_message, count, count)
                )
                .setPositiveButton(R.string.button_delete) { _, _ ->
                    confirmDeleteIntent.onNext(conversations)
                }
                .setNegativeButton(R.string.button_cancel, null)
                .create()

        dialog.show()
    }

    override fun goBack() {
        router.popCurrentController()
    }
}
