/*
 * SPDX-FileCopyrightText: 2025 gavine99 <github@xymail.tk>
 * SPDX-FileCopyrightText: Saalim Quadri <danascape@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.feature.extensions

import android.content.Context
import android.graphics.drawable.Drawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.widget.ImageView
import androidx.appcompat.content.res.AppCompatResources
import com.bumptech.glide.Glide
import ir.pmessages.app.R
import ir.pmessages.app.extensions.getDefaultActivityIconForMimeType
import ir.pmessages.app.extensions.isAudio
import ir.pmessages.app.extensions.isImage
import ir.pmessages.app.extensions.isVideo
import ir.pmessages.app.extensions.resourceExists
import timber.log.Timber

enum class LoadBestIconIntoImageView {
    Missing,
    ImageVideoIcon,
    EmbeddedIcon,
    DefaultAudioIcon,
    ActivityIcon,
    GenericIcon,
}

fun Uri.loadBestIconIntoImageView(
    context: Context,
    imageView: ImageView,
): LoadBestIconIntoImageView {

    // if resource is missing, use missing icon
    if (!resourceExists(context)) {
        Glide.with(context).load(android.R.drawable.ic_delete).into(imageView)
        return LoadBestIconIntoImageView.Missing
    }

    // if attachment is image or video use image or video frame for icon
    if (isImage(context) || isVideo(context)) {
        Glide.with(context).load(this).into(imageView)
        return LoadBestIconIntoImageView.ImageVideoIcon
    }

    var appIcon: Drawable? = null

    var retVal = LoadBestIconIntoImageView.EmbeddedIcon

    // if audio mime type, try and use embedded image (ie. id3 cover art) if one exists
    if (isAudio(context)) {
        val embeddedPicture = embeddedPicture(context)
        if (embeddedPicture != null) {
            Glide.with(context).load(embeddedPicture).into(imageView)
            return retVal
        }

        // else, use applications built-in audio icon
        appIcon = AppCompatResources.getDrawable(context, R.drawable.ic_round_volume_up_24)
        retVal = LoadBestIconIntoImageView.DefaultAudioIcon
    }

    // not audio, try and get icon from default activity for type
    if (appIcon == null) {
        appIcon = getDefaultActivityIconForMimeType(context)
        retVal = LoadBestIconIntoImageView.ActivityIcon
    }

    // else, use default local generic attachment icon
    if (appIcon == null) {
        appIcon = AppCompatResources.getDrawable(context, R.drawable.ic_attachment_black_24dp)
        retVal = LoadBestIconIntoImageView.GenericIcon
    }

    // load icon
    Glide.with(context).load(appIcon).into(imageView)

    return retVal
}

fun Uri.embeddedPicture(context: Context): ByteArray? {
    val retriever = MediaMetadataRetriever()
    return try {
        retriever.setDataSource(context, this)
        retriever.embeddedPicture
    } catch (e: RuntimeException) {
        Timber.w(e)
        null
    } finally {
        runCatching { retriever.release() }
    }
}
