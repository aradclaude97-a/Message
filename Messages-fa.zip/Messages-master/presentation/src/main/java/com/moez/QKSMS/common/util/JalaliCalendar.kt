/*
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.common.util

import java.util.Calendar
import java.util.Locale

/** Gregorian <-> Jalali (Shamsi) conversion and Persian formatting helpers. */
object JalaliCalendar {

    val monthNames =
        arrayOf(
            "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
            "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند",
        )

    /** Indexed by [Calendar.DAY_OF_WEEK] - 1 (Sunday first). */
    val weekdayNames =
        arrayOf("یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه")

    data class Date(val year: Int, val month: Int, val day: Int)

    /** Jalali is used whenever the UI language is Persian. */
    fun isActive(locale: Locale = Locale.getDefault()): Boolean = locale.language == "fa"

    fun fromGregorian(gy: Int, gm: Int, gd: Int): Date {
        val cumulative = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
        val gy2 = if (gm > 2) gy + 1 else gy
        var days =
            355666 + 365 * gy + (gy2 + 3) / 4 - (gy2 + 99) / 100 + (gy2 + 399) / 400 + gd +
                cumulative[gm - 1]
        var jy = -1595 + 33 * (days / 12053)
        days %= 12053
        jy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            jy += (days - 1) / 365
            days = (days - 1) % 365
        }
        val jm: Int
        val jd: Int
        if (days < 186) {
            jm = 1 + days / 31
            jd = 1 + days % 31
        } else {
            jm = 7 + (days - 186) / 30
            jd = 1 + (days - 186) % 30
        }
        return Date(jy, jm, jd)
    }

    fun fromCalendar(cal: Calendar): Date =
        fromGregorian(
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.DAY_OF_MONTH),
        )

    /** Returns the Gregorian date as (year, month 1-12, day). */
    fun toGregorian(jy0: Int, jm: Int, jd: Int): Triple<Int, Int, Int> {
        val jy = jy0 + 1595
        var days =
            -355668 + 365 * jy + (jy / 33) * 8 + ((jy % 33) + 3) / 4 + jd +
                (if (jm < 7) (jm - 1) * 31 else (jm - 7) * 30 + 186)
        var gy = 400 * (days / 146097)
        days %= 146097
        if (days > 36524) {
            days--
            gy += 100 * (days / 36524)
            days %= 36524
            if (days >= 365) days++
        }
        gy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            gy += (days - 1) / 365
            days = (days - 1) % 365
        }
        var gd = days + 1
        val leap = (gy % 4 == 0 && gy % 100 != 0) || gy % 400 == 0
        val monthDays = intArrayOf(0, 31, if (leap) 29 else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
        var gm = 0
        while (gm < 13 && gd > monthDays[gm]) {
            gd -= monthDays[gm]
            gm++
        }
        return Triple(gy, gm, gd)
    }

    fun isLeap(jy: Int): Boolean {
        // A Jalali year is leap when Esfand has a 30th day.
        val (gy, gm, gd) = toGregorian(jy, 12, 30)
        return fromGregorian(gy, gm, gd) == Date(jy, 12, 30)
    }

    fun daysInMonth(jy: Int, jm: Int): Int =
        when {
            jm <= 6 -> 31
            jm <= 11 -> 30
            else -> if (isLeap(jy)) 30 else 29
        }

    /** Replaces ASCII digits with Persian digits. */
    fun toPersianDigits(input: String): String {
        val sb = StringBuilder(input.length)
        for (c in input) sb.append(if (c in '0'..'9') ('۰' + (c - '0')) else c)
        return sb.toString()
    }

    fun toPersianDigits(value: Int): String = toPersianDigits(value.toString())
}
