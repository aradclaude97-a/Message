/*
 * SPDX-FileCopyrightText: 2018 Moez Bhatti <moez.bhatti@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.feature.blocking.filters

import io.realm.RealmResults
import ir.pmessages.app.model.MessageContentFilter

data class MessageContentFiltersState(val filters: RealmResults<MessageContentFilter>? = null)
