/*
 * SPDX-FileCopyrightText: 2018 Moez Bhatti <moez.bhatti@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.feature.conversationinfo

import android.content.Context
import androidx.lifecycle.Lifecycle
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDispose
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.rxkotlin.Observables
import io.reactivex.rxkotlin.plusAssign
import io.reactivex.schedulers.Schedulers
import io.reactivex.subjects.BehaviorSubject
import io.reactivex.subjects.Subject
import javax.inject.Inject
import javax.inject.Named
import ir.pmessages.app.R
import ir.pmessages.app.common.Navigator
import ir.pmessages.app.common.base.QkPresenter
import ir.pmessages.app.common.util.ClipboardUtils
import ir.pmessages.app.common.util.extensions.makeToast
import ir.pmessages.app.extensions.asObservable
import ir.pmessages.app.extensions.mapNotNull
import ir.pmessages.app.feature.conversationinfo.ConversationInfoItem.ConversationInfoRecipient
import ir.pmessages.app.interactor.DeleteConversations
import ir.pmessages.app.interactor.MarkArchived
import ir.pmessages.app.interactor.MarkUnarchived
import ir.pmessages.app.interactor.MarkUnread
import ir.pmessages.app.manager.PermissionManager
import ir.pmessages.app.model.Conversation
import ir.pmessages.app.repository.ConversationRepository
import ir.pmessages.app.repository.MessageRepository

class ConversationInfoPresenter
@Inject
constructor(
    @Named("threadId") threadId: Long,
    messageRepo: MessageRepository,
    private val context: Context,
    private val conversationRepo: ConversationRepository,
    private val deleteConversations: DeleteConversations,
    private val markUnread: MarkUnread,
    private val markArchived: MarkArchived,
    private val markUnarchived: MarkUnarchived,
    private val navigator: Navigator,
    private val permissionManager: PermissionManager,
) :
    QkPresenter<ConversationInfoView, ConversationInfoState>(
        ConversationInfoState(threadId = threadId)
    ) {

    private val conversation: Subject<Conversation> = BehaviorSubject.create()

    init {
        disposables +=
            conversationRepo
                .getConversationAsync(threadId)
                .asObservable()
                .filter { conversation -> conversation.isLoaded }
                .doOnNext { conversation ->
                    if (!conversation.isValid) {
                        newState { copy(hasError = true) }
                    }
                }
                .filter { conversation -> conversation.isValid }
                .filter { conversation -> conversation.id != 0L }
                .subscribe(conversation::onNext)

        disposables += markArchived
        disposables += markUnarchived
        disposables += deleteConversations

        disposables +=
            Observables.combineLatest(
                    conversation,
                    messageRepo.getPartsForConversation(threadId).asObservable(),
                ) { conversation, parts ->
                    val header = mutableListOf<ConversationInfoItem>()

                    // If some data was deleted, this isn't the place to handle it
                    if (
                        !conversation.isLoaded ||
                            !conversation.isValid ||
                            !parts.isLoaded ||
                            !parts.isValid
                    ) {
                        return@combineLatest
                    }

                    header += conversation.recipients.map(::ConversationInfoRecipient)
                    header +=
                        ConversationInfoItem.ConversationInfoSettings(
                            name = conversation.name,
                            recipients = conversation.recipients,
                            archived = conversation.archived,
                            blocked = conversation.blocked,
                        )

                    val data = ConversationInfoItems(header, parts.createSnapshot())
                    newState { copy(data = data) }
                }
                .subscribe()
    }

    override fun bindIntents(view: ConversationInfoView) {
        super.bindIntents(view)

        // Add or display the contact
        view
            .recipientClicks()
            .mapNotNull(conversationRepo::getRecipient)
            .doOnNext { recipient ->
                recipient.contact?.lookupKey?.let(navigator::showContact)
                    ?: navigator.addContact(recipient.address)
            }
            .autoDispose(view.scope(Lifecycle.Event.ON_DESTROY)) // ... this should be the default
            .subscribe()

        // Copy phone number
        view
            .recipientLongClicks()
            .mapNotNull(conversationRepo::getRecipient)
            .map { recipient -> recipient.address }
            .observeOn(AndroidSchedulers.mainThread())
            .autoDispose(view.scope())
            .subscribe { address ->
                ClipboardUtils.copy(context, address)
                context.makeToast(R.string.info_copied_address)
            }

        // Show the theme settings for the conversation
        view.themeClicks().autoDispose(view.scope()).subscribe(view::showThemePicker)

        // Show the conversation title dialog
        view
            .nameClicks()
            .withLatestFrom(conversation) { _, conversation -> conversation }
            .map { conversation -> conversation.name }
            .autoDispose(view.scope())
            .subscribe(view::showNameDialog)

        // Set the conversation title
        view
            .nameChanges()
            .withLatestFrom(conversation) { name, conversation ->
                conversationRepo
                    .setConversationName(conversation.id, name)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
            }
            .flatMapCompletable { it }
            .autoDispose(view.scope())
            .subscribe()

        // Show the notifications settings for the conversation
        view
            .notificationClicks()
            .withLatestFrom(conversation) { _, conversation -> conversation }
            .autoDispose(view.scope())
            .subscribe { conversation -> navigator.showNotificationSettings(conversation.id) }

        view
            .markUnreadClicks()
            .withLatestFrom(conversation) { _, conversation -> conversation }
            .autoDispose(view.scope())
            .subscribe { conversation ->
                markUnread.execute(listOf(conversation.id))
                navigator.showMainActivity()
            }

        // Toggle the archived state of the conversation
        view
            .archiveClicks()
            .withLatestFrom(conversation) { _, conversation -> conversation }
            .autoDispose(view.scope())
            .subscribe { conversation ->
                when (conversation.archived) {
                    true -> markUnarchived.execute(listOf(conversation.id))
                    false -> markArchived.execute(listOf(conversation.id))
                }
            }

        // Toggle the blocked state of the conversation
        view
            .blockClicks()
            .withLatestFrom(conversation) { _, conversation -> conversation }
            .autoDispose(view.scope())
            .subscribe { conversation ->
                view.showBlockingDialog(listOf(conversation.id), !conversation.blocked)
            }

        // Show the delete confirmation dialog
        view
            .deleteClicks()
            .filter { permissionManager.isDefaultSms().also { if (!it) view.requestDefaultSms() } }
            .autoDispose(view.scope())
            .subscribe { view.showDeleteDialog() }

        // Delete the conversation
        view
            .confirmDelete()
            .withLatestFrom(conversation) { _, conversation -> conversation }
            .autoDispose(view.scope())
            .subscribe { conversation -> deleteConversations.execute(listOf(conversation.id)) }

        // Media
        view.mediaClicks().autoDispose(view.scope()).subscribe(navigator::showMedia)
    }
}
