/*
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.common.util

import android.content.Context
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton
import org.json.JSONArray
import org.json.JSONObject

data class Category(val id: String, val name: String, val threadIds: Set<Long>)

/**
 * Stores the user's custom inbox categories (name + conversations) and the customisation of the
 * built-in filter chips (renamed / hidden). Everything is persisted as JSON in SharedPreferences.
 */
@Singleton
class CategoryStore @Inject constructor(context: Context) {

    companion object {
        const val KEY_ALL = "all"
        const val KEY_UNREAD = "unread"
        const val KEY_ARCHIVED = "archived"
        private const val PREFS = "categories"
        private const val KEY_CATEGORIES = "categories_v1"
        private const val KEY_BUILTIN = "builtin_v1"
    }

    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // ---- Custom categories ------------------------------------------------------------------

    @Synchronized
    fun categories(): List<Category> {
        val raw = prefs.getString(KEY_CATEGORIES, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            (0 until array.length()).map { i ->
                val obj = array.getJSONObject(i)
                val ids = obj.optJSONArray("threads") ?: JSONArray()
                Category(
                    obj.getString("id"),
                    obj.getString("name"),
                    (0 until ids.length()).map { ids.getLong(it) }.toSet(),
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    @Synchronized
    private fun save(list: List<Category>) {
        val array = JSONArray()
        list.forEach { category ->
            val ids = JSONArray()
            category.threadIds.forEach { ids.put(it) }
            array.put(
                JSONObject()
                    .put("id", category.id)
                    .put("name", category.name)
                    .put("threads", ids)
            )
        }
        prefs.edit().putString(KEY_CATEGORIES, array.toString()).apply()
    }

    @Synchronized
    fun add(name: String, threadIds: Collection<Long> = emptyList()): Category {
        val category = Category(UUID.randomUUID().toString(), name.trim(), threadIds.toSet())
        save(categories() + category)
        return category
    }

    @Synchronized
    fun rename(id: String, name: String) {
        save(categories().map { if (it.id == id) it.copy(name = name.trim()) else it })
    }

    @Synchronized
    fun delete(id: String) {
        save(categories().filter { it.id != id })
    }

    @Synchronized
    fun setMembership(id: String, threadIds: Collection<Long>, member: Boolean) {
        save(
            categories().map {
                if (it.id != id) it
                else it.copy(threadIds = if (member) it.threadIds + threadIds else it.threadIds - threadIds.toSet())
            }
        )
    }

    fun threadIds(id: String?): Set<Long> = categories().firstOrNull { it.id == id }?.threadIds ?: emptySet()

    // ---- Built-in chips (all / unread / archived) -------------------------------------------

    private fun builtin(): JSONObject =
        try {
            JSONObject(prefs.getString(KEY_BUILTIN, "{}") ?: "{}")
        } catch (e: Exception) {
            JSONObject()
        }

    fun builtinName(key: String, default: String): String {
        val name = builtin().optJSONObject(key)?.optString("name", "") ?: ""
        return name.ifBlank { default }
    }

    fun isBuiltinHidden(key: String): Boolean =
        builtin().optJSONObject(key)?.optBoolean("hidden", false) ?: false

    @Synchronized
    fun setBuiltinName(key: String, name: String) {
        val all = builtin()
        val entry = all.optJSONObject(key) ?: JSONObject()
        entry.put("name", name.trim())
        all.put(key, entry)
        prefs.edit().putString(KEY_BUILTIN, all.toString()).apply()
    }

    @Synchronized
    fun setBuiltinHidden(key: String, hidden: Boolean) {
        val all = builtin()
        val entry = all.optJSONObject(key) ?: JSONObject()
        entry.put("hidden", hidden)
        all.put(key, entry)
        prefs.edit().putString(KEY_BUILTIN, all.toString()).apply()
    }

    @Synchronized
    fun resetBuiltins() {
        prefs.edit().remove(KEY_BUILTIN).apply()
    }
}
