/*
 * SPDX-FileCopyrightText: 2017 Moez Bhatti <moez.bhatti@gmail.com>
 * SPDX-FileCopyrightText: Saalim Quadri <danascape@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.feature.compose

import android.net.Uri
import android.view.MenuItem
import android.view.View
import androidx.annotation.StringRes
import androidx.core.view.inputmethod.InputContentInfoCompat
import com.moez.QKSMS.common.QkMediaPlayer
import io.reactivex.Observable
import io.reactivex.subjects.Subject
import ir.pmessages.app.common.base.QkView
import ir.pmessages.app.common.base.Selection
import ir.pmessages.app.common.widget.MicInputCloudView
import ir.pmessages.app.model.Attachment
import ir.pmessages.app.model.Recipient

data class ReactionSelection(
    val messageId: Long,
    val emoji: String,
    val isRemoval: Boolean = false,
)

data class MessageLongPress(val messageId: Long, val body: String, val anchor: View)

interface ComposeView : QkView<ComposeState> {

    companion object {
        const val SelectContactRequestCode = 0
        const val TakePhotoRequestCode = 1
        const val AttachContactRequestCode = 3
        const val AttachAFileRequestCode = 4

        const val CameraDestinationKey = "camera_destination"
    }

    val activityVisibleIntent: Observable<Boolean>
    val chipsSelectedIntent: Subject<HashMap<String, String?>>
    val chipDeletedIntent: Subject<Recipient>
    val menuReadyIntent: Observable<Unit>
    val optionsItemIntent: Observable<Int>
    val contextItemIntent: Observable<MenuItem>
    val sendAsGroupIntent: Observable<*>
    val messagePartClickIntent: Subject<Long>
    val messagePartContextMenuRegistrar: Subject<View>
    val messagesSelectedIntent: Observable<Selection>
    val cancelSendingIntent: Subject<Long>
    val sendNowIntent: Subject<Long>
    val resendIntent: Subject<Long>
    val downloadMmsIntent: Subject<Long>
    val attachmentDeletedIntent: Subject<Attachment>
    val textChangedIntent: Observable<CharSequence>
    val attachIntent: Observable<Unit>
    val cameraIntent: Observable<*>
    val attachAnyFileIntent: Observable<*>
    val attachImageFileIntent: Observable<*>
    val scheduleIntent: Observable<*>
    val scheduleAction: Observable<*>
    val attachContactIntent: Observable<*>
    val attachAnyFileSelectedIntent: Observable<Uri>
    val contactSelectedIntent: Observable<Uri>
    val inputContentIntent: Observable<InputContentInfoCompat>
    val scheduleSelectedIntent: Observable<Long>
    val scheduleCancelIntent: Observable<*>
    val changeSimIntent: Observable<*>
    val sendIntent: Observable<Unit>
    val viewQksmsPlusIntent: Subject<Unit>
    val backPressedIntent: Observable<Unit>
    val confirmDeleteIntent: Observable<Selection>
    val clearCurrentMessageIntent: Subject<Boolean>
    val messageLinkAskIntent: Observable<Uri>
    val shadeIntent: Observable<Unit>
    val recordAudioStartStopRecording: Subject<Boolean>
    val recordAnAudioMessage: Observable<Unit>
    val recordAudioAbort: Observable<Unit>
    val recordAudioAttach: Observable<Unit>
    val recordAudioPlayerPlayPause: Observable<QkMediaPlayer.PlayingState>
    val recordAudioPlayerConfigUI: Subject<QkMediaPlayer.PlayingState>
    val recordAudioPlayerVisible: Subject<Boolean>
    val recordAudioMsgRecordVisible: Subject<Boolean>
    val recordAudioRecord: Subject<MicInputCloudView.ViewState>
    val recordAudioChronometer: Subject<Boolean>
    val reactionSelectedIntent: Subject<ReactionSelection>
    val messageLongPressIntent: Observable<MessageLongPress>

    fun clearSelection()

    fun toggleSelectAll()

    fun expandMessages(selection: Selection)

    fun showDetails(details: String)

    fun showMessageLinkAskDialog(uri: Uri)

    fun requestDefaultSms()

    fun requestStoragePermission()

    fun requestRecordAudioPermission()

    fun requestSmsPermission()

    fun showContacts(sharing: Boolean, chips: List<Recipient>)

    fun themeChanged()

    fun showKeyboard()

    fun requestCamera()

    fun requestGallery(mimeType: String, requestCode: Int)

    fun requestFile()

    fun requestDatePicker()

    fun requestContact()

    fun setDraft(draft: String)

    fun scrollToMessage(id: Long)

    fun showQksmsPlusSnackbar(@StringRes message: Int)

    fun showDeleteDialog(selection: Selection)

    fun showClearCurrentMessageDialog()

    fun focusMessage()

    fun showReactionPicker(messageId: Long)
}
