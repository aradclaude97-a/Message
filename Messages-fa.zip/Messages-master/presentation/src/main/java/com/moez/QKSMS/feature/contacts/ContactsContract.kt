/*
 * SPDX-FileCopyrightText: 2019 Moez Bhatti <moez.bhatti@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.feature.contacts

import io.reactivex.Observable
import io.reactivex.subjects.Subject
import ir.pmessages.app.common.base.QkView
import ir.pmessages.app.extensions.Optional
import ir.pmessages.app.feature.compose.editing.ComposeItem
import ir.pmessages.app.feature.compose.editing.PhoneNumberAction

interface ContactsContract : QkView<ContactsState> {

    val queryChangedIntent: Observable<CharSequence>
    val queryClearedIntent: Observable<*>
    val queryEditorActionIntent: Observable<Int>
    val composeItemPressedIntent: Subject<ComposeItem>
    val composeItemLongPressedIntent: Subject<ComposeItem>
    val phoneNumberSelectedIntent: Subject<Optional<Long>>
    val phoneNumberActionIntent: Subject<PhoneNumberAction>

    fun clearQuery()

    fun openKeyboard()

    fun finish(result: HashMap<String, String?>)
}
