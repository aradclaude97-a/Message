/*
 * SPDX-FileCopyrightText: 2025 gavine99 <github@xymail.tk>
 * SPDX-FileCopyrightText: Saalim Quadri <danascape@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.feature.extensions

import android.text.Spannable
import androidx.emoji2.text.EmojiCompat
import androidx.emoji2.text.EmojiCompat.REPLACE_STRATEGY_ALL
import androidx.emoji2.text.EmojiSpan

fun CharSequence.isEmojiOnly(considerWhitespace: Boolean = false): Boolean {
    val cs = if (considerWhitespace) this else this.replace(Regex("[\\s\n\r]"), "")

    if (cs.isEmpty()) return false

    val emojiCompat = if (EmojiCompat.isConfigured()) EmojiCompat.get() else return false
    if (emojiCompat.loadState != EmojiCompat.LOAD_STATE_SUCCEEDED) return false

    return when (
        val spannable =
            emojiCompat.process(cs, 0, (cs.length - 1), Int.MAX_VALUE, REPLACE_STRATEGY_ALL)
    ) {
        is Spannable -> {
            (spannable.getSpans(0, (spannable.length - 1), EmojiSpan::class.java).fold(0) {
                acc,
                emojiSpan ->
                acc + (spannable.getSpanEnd(emojiSpan) - spannable.getSpanStart(emojiSpan))
            } == cs.length)
        }
        else -> false
    }
}
