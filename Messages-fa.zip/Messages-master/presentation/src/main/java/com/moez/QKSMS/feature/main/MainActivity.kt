/*
 * SPDX-FileCopyrightText: 2017 Moez Bhatti <moez.bhatti@gmail.com>
 * SPDX-FileCopyrightText: Saalim Quadri <danascape@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.feature.main

import android.Manifest
import android.animation.ObjectAnimator
import android.content.Intent
import android.content.res.ColorStateList
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.view.ViewStub
import android.widget.ProgressBar
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.PopupMenu
import androidx.core.app.ActivityCompat
import androidx.core.view.GravityCompat
import androidx.core.view.get
import androidx.core.view.isVisible
import androidx.core.view.size
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.chip.Chip
import com.google.android.material.snackbar.Snackbar
import com.jakewharton.rxbinding2.view.clicks
import com.jakewharton.rxbinding2.widget.textChanges
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDispose
import dagger.android.AndroidInjection
import io.reactivex.Observable
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import javax.inject.Inject
import ir.pmessages.app.R
import ir.pmessages.app.common.Navigator
import ir.pmessages.app.common.androidxcompat.drawerOpen
import ir.pmessages.app.common.base.QkThemedActivity
import ir.pmessages.app.common.util.Category
import ir.pmessages.app.common.util.CategoryStore
import ir.pmessages.app.common.util.extensions.autoScrollToStart
import ir.pmessages.app.common.util.extensions.dismissKeyboard
import ir.pmessages.app.common.util.extensions.resolveThemeColor
import ir.pmessages.app.common.util.extensions.scrapViews
import ir.pmessages.app.common.util.extensions.setBackgroundTint
import ir.pmessages.app.common.util.extensions.setTint
import ir.pmessages.app.common.util.extensions.setVisible
import ir.pmessages.app.common.widget.TextInputDialog
import ir.pmessages.app.databinding.MainActivityBinding
import ir.pmessages.app.feature.blocking.BlockingDialog
import ir.pmessages.app.feature.changelog.ChangelogDialog
import ir.pmessages.app.feature.conversations.ConversationItemTouchCallback
import ir.pmessages.app.feature.conversations.ConversationsAdapter
import ir.pmessages.app.manager.ChangelogManager
import ir.pmessages.app.repository.SyncRepository

class MainActivity : QkThemedActivity<MainActivityBinding>(MainActivityBinding::inflate), MainView {

    @Inject lateinit var blockingDialog: BlockingDialog

    @Inject lateinit var categoryStore: CategoryStore

    @Inject lateinit var disposables: CompositeDisposable

    @Inject lateinit var navigator: Navigator

    @Inject lateinit var conversationsAdapter: ConversationsAdapter

    @Inject lateinit var drawerBadgesExperiment: DrawerBadgesExperiment

    @Inject lateinit var searchAdapter: SearchAdapter

    @Inject lateinit var itemTouchCallback: ConversationItemTouchCallback

    @Inject lateinit var viewModelFactory: ViewModelProvider.Factory

    override val onNewIntentIntent: Subject<Intent> = PublishSubject.create()
    override val activityResumedIntent: Subject<Boolean> = PublishSubject.create()
    override val queryChangedIntent by lazy { binding.toolbarSearch.textChanges() }
    override val composeIntent by lazy { binding.compose.clicks() }
    override val filterSelectedIntent by lazy {
        Observable.merge(
            binding.filterAll.clicks().map { MessageCategory.ALL },
            binding.filterUnread.clicks().map { MessageCategory.UNREAD },
            binding.filterArchived.clicks().map { MessageCategory.ARCHIVED },
            builtinFilterSubject,
        )
    }
    private val builtinFilterSubject: Subject<MessageCategory> = PublishSubject.create()
    override val customCategorySelectedIntent: Subject<String> = PublishSubject.create()
    override val drawerToggledIntent: Observable<Boolean> by lazy {
        binding.drawerLayout.drawerOpen(Gravity.START)
    }
    override val homeIntent: Subject<Unit> = PublishSubject.create()

    private val menuClickSubject: Subject<Unit> = PublishSubject.create()
    override val navigationIntent: Observable<NavItem> by lazy {
        Observable.merge(
            listOf(
                backPressedSubject,
                binding.drawer.inbox.clicks().map { NavItem.INBOX },
                binding.drawer.archived.clicks().map { NavItem.ARCHIVED },
                binding.drawer.backup.clicks().map { NavItem.BACKUP },
                binding.drawer.scheduled.clicks().map { NavItem.SCHEDULED },
                binding.drawer.blocking.clicks().map { NavItem.BLOCKING },
                binding.drawer.settings.clicks().map { NavItem.SETTINGS },
                //                plus.clicks().map { NavItem.PLUS },
                //                help.clicks().map { NavItem.HELP },
                binding.drawer.invite.clicks().map { NavItem.INVITE },
            )
        )
    }
    override val optionsItemIntent: Subject<Int> = PublishSubject.create()

    //    override val plusBannerIntent by lazy { plusBanner.clicks() }
    override val dismissRatingIntent by lazy { binding.drawer.rateDismiss.clicks() }
    override val rateIntent by lazy { binding.drawer.rateOkay.clicks() }
    override val conversationsSelectedIntent by lazy { conversationsAdapter.selectionChanges }
    override val confirmDeleteIntent: Subject<List<Long>> = PublishSubject.create()
    override val renameConversationIntent: Subject<String> = PublishSubject.create()
    override val swipeConversationIntent by lazy { itemTouchCallback.swipes }
    override val changelogMoreIntent by lazy { changelogDialog.moreClicks }
    override val undoArchiveIntent: Subject<Unit> = PublishSubject.create()
    override val snackbarButtonIntent: Subject<Unit> = PublishSubject.create()

    private val viewModel by lazy {
        ViewModelProvider(this, viewModelFactory)[MainViewModel::class.java]
    }
    private val toggle by lazy {
        ActionBarDrawerToggle(
            this,
            binding.drawerLayout,
            binding.toolbar,
            R.string.main_drawer_open_cd,
            0,
        )
    }
    private val itemTouchHelper by lazy { ItemTouchHelper(itemTouchCallback) }
    private val changelogDialog by lazy { ChangelogDialog(this) }
    private val backPressedSubject: Subject<NavItem> = PublishSubject.create()

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        viewModel.bindView(this)
        onNewIntentIntent.onNext(intent)

        (binding.snackbar as? ViewStub)?.setOnInflateListener { _, inflated ->
            inflated
                .findViewById<View>(R.id.snackbarButton)
                .clicks()
                .autoDispose(scope(Lifecycle.Event.ON_DESTROY))
                .subscribe(snackbarButtonIntent)
        }

        (binding.syncing as? ViewStub)?.setOnInflateListener { _, inflated ->
            inflated.findViewById<ProgressBar>(R.id.syncingProgress)?.let {
                it.progressTintList = ColorStateList.valueOf(theme.blockingFirst().theme)
                it.indeterminateTintList = ColorStateList.valueOf(theme.blockingFirst().theme)
            }
        }

        binding.btnChangeDefaultSms.setOnClickListener { requestDefaultSms() }

        binding.clearSearch.clicks().autoDispose(scope()).subscribe { clearSearch() }

        binding.toolbarSearch.textChanges().autoDispose(scope()).subscribe { text ->
            binding.clearSearch.isVisible = text.isNotEmpty()
        }

        conversationsAdapter.selectionChanges.autoDispose(scope()).subscribe { ids ->
            lastSelection = ids.toList()
        }
        rebuildChips()

        toggle.syncState()
        title = ""
        binding.toolbar.setNavigationOnClickListener {
            dismissKeyboard()
            homeIntent.onNext(Unit)
        }

        binding.cVTopBar3.clicks().autoDispose(scope()).subscribe { showDrawerMenu() }

        itemTouchCallback.adapter = conversationsAdapter
        conversationsAdapter.autoScrollToStart(binding.recyclerView)

        // Setup search adapter click listener
        searchAdapter.onMessageClickListener = { conversationId, messageId ->
            navigator.showConversation(conversationId, messageId)
        }

        binding.fastScroller.setupWithRecyclerView(binding.recyclerView)

        // Don't allow clicks to pass through the drawer layout
        binding.drawer.root.clicks().autoDispose(scope()).subscribe()

        // Set the theme color tint to the recyclerView, progressbar, and FAB
        theme.autoDispose(scope()).subscribe { theme ->
            // Set the color for the drawer icons
            val states =
                arrayOf(
                    intArrayOf(android.R.attr.state_activated),
                    intArrayOf(-android.R.attr.state_activated),
                )

            ColorStateList(
                    states,
                    intArrayOf(theme.theme, resolveThemeColor(android.R.attr.textColorSecondary)),
                )
                .let { tintList ->
                    binding.drawer.inboxIcon.imageTintList = tintList
                    binding.drawer.archivedIcon.imageTintList = tintList
                }

            // Miscellaneous views
            listOf(binding.drawer.plusBadge1, binding.drawer.plusBadge2).forEach { badge ->
                badge.setBackgroundTint(theme.theme)
                badge.setTextColor(theme.textPrimary)
            }
            (binding.syncing as? ViewStub)?.findViewById<ProgressBar>(R.id.syncingProgress)?.let {
                it.progressTintList = ColorStateList.valueOf(theme.theme)
                it.indeterminateTintList = ColorStateList.valueOf(theme.theme)
            }
            binding.drawer.plusIcon.setTint(theme.theme)
            binding.drawer.rateIcon.setTint(theme.theme)

            val primaryTextColor = resolveThemeColor(android.R.attr.textColorPrimary)
            val secondaryTextColor = resolveThemeColor(android.R.attr.textColorSecondary)
            binding.searchIcon.setTint(primaryTextColor)
            binding.clearSearch.setTint(primaryTextColor)
            binding.toolbarSearch.setTextColor(primaryTextColor)
            binding.toolbarSearch.setHintTextColor(secondaryTextColor)

            binding.messagesText.setTextColor(primaryTextColor)
            binding.menuIcon.setTint(primaryTextColor)

            binding.compose.setTint(primaryTextColor)
        }
    }

    override fun onNewIntent(intent: Intent?) =
        intent?.let {
            super.onNewIntent(intent)
            it.run(onNewIntentIntent::onNext)
        } ?: Unit

    override fun render(state: MainState) {
        lastState = state
        if (state.hasError) {
            finish()
            return
        }

        if (!state.defaultSms) {
            binding.notDefaultSmsView.setVisible(true)
            binding.recyclerView.setVisible(false)
            binding.empty.setVisible(false)
            binding.searchPill.setVisible(false)
            binding.compose.setVisible(false)
            binding.filterScroll.setVisible(false)
            return
        } else {
            binding.notDefaultSmsView.setVisible(false)
        }

        val addContact =
            when (state.page) {
                is Inbox -> state.page.addContact
                is Archived -> state.page.addContact
                else -> false
            }

        val markPinned =
            when (state.page) {
                is Inbox -> state.page.markPinned
                is Archived -> state.page.markPinned
                else -> true
            }

        val markRead =
            when (state.page) {
                is Inbox -> state.page.markRead
                is Archived -> state.page.markRead
                else -> true
            }

        val selectedConversations =
            when (state.page) {
                is Inbox -> state.page.selected
                is Archived -> state.page.selected
                else -> 0
            }

        val hasSelection = selectedConversations > 0
        binding.toolbar.setVisible(hasSelection)

        binding.cVTopBar2.setVisible(!hasSelection)
        binding.cVTopBar3.setVisible(!hasSelection)

        binding.toolbarSearch.setVisible(
            (state.page is Inbox && state.page.selected == 0) ||
                (state.page is Archived && state.page.selected == 0) ||
                state.page is Searching
        )
        binding.toolbarTitle.setVisible(true)
        binding.filterScroll.setVisible(state.page is Inbox || state.page is Archived)

        binding.toolbar.menu.apply {
            findItem(R.id.select_all)?.isVisible =
                (conversationsAdapter.itemCount > 1) && selectedConversations != 0
            findItem(R.id.archive)?.isVisible = state.page is Inbox && selectedConversations != 0
            findItem(R.id.unarchive)?.isVisible =
                state.page is Archived && selectedConversations != 0
            findItem(R.id.delete)?.isVisible = selectedConversations != 0
            findItem(R.id.category)?.isVisible =
                state.page is Inbox && selectedConversations != 0
            findItem(R.id.add)?.isVisible = addContact && selectedConversations != 0
            findItem(R.id.pin)?.isVisible = markPinned && selectedConversations != 0
            findItem(R.id.unpin)?.isVisible = !markPinned && selectedConversations != 0
            findItem(R.id.read)?.isVisible =
                (markRead && selectedConversations != 0) || selectedConversations > 1
            findItem(R.id.unread)?.isVisible =
                (!markRead && selectedConversations != 0) || selectedConversations > 1
            findItem(R.id.block)?.isVisible = selectedConversations != 0
            findItem(R.id.rename)?.isVisible = selectedConversations == 1
        }

        listOf(binding.drawer.plusBadge1, binding.drawer.plusBadge2).forEach { badge ->
            badge.isVisible = drawerBadgesExperiment.variant && !state.upgraded
        }
        //        plus.isVisible = state.upgraded
        binding.drawer.plusBanner.isVisible = !state.upgraded
        binding.drawer.rateLayout.setVisible(state.showRating)

        binding.compose.setVisible(state.page is Inbox || state.page is Archived)
        conversationsAdapter.emptyView =
            binding.empty.takeIf { state.page is Inbox || state.page is Archived }
        searchAdapter.emptyView = binding.empty.takeIf { state.page is Searching }

        when (state.page) {
            is Inbox -> {
                showBackButton(state.page.selected > 0)
                binding.toolbarTitle.text =
                    when {
                        state.page.selected > 0 ->
                            getString(R.string.main_title_selected, state.page.selected)

                        else -> getString(R.string.app_name)
                    }
                if (binding.recyclerView.adapter !== conversationsAdapter)
                    binding.recyclerView.adapter = conversationsAdapter
                conversationsAdapter.updateData(state.page.data)
                itemTouchHelper.attachToRecyclerView(binding.recyclerView)
                binding.empty.setText(R.string.inbox_empty_text)
            }

            is Searching -> {
                showBackButton(true)
                binding.toolbarTitle.text = getString(R.string.title_conversations)
                if (binding.recyclerView.adapter !== searchAdapter)
                    binding.recyclerView.adapter = searchAdapter
                searchAdapter.data = state.page.data ?: listOf()
                searchAdapter.setQuery(binding.toolbarSearch.text.toString())
                itemTouchHelper.attachToRecyclerView(null)
                binding.empty.setText(R.string.inbox_search_empty_text)
            }

            is Archived -> {
                showBackButton(state.page.selected > 0)
                binding.toolbarTitle.text =
                    when {
                        state.page.selected > 0 ->
                            getString(R.string.main_title_selected, state.page.selected)

                        else -> getString(R.string.title_archived)
                    }
                if (binding.recyclerView.adapter !== conversationsAdapter)
                    binding.recyclerView.adapter = conversationsAdapter
                conversationsAdapter.updateData(state.page.data)
                itemTouchHelper.attachToRecyclerView(null)
                binding.empty.setText(R.string.archived_empty_text)
            }

            else -> {
                binding.toolbarTitle.text = getString(R.string.app_name)
            }
        }

        updateChipChecks(state)

        binding.drawer.inbox.isActivated = state.page is Inbox
        binding.drawer.archived.isActivated = state.page is Archived

        if (binding.drawerLayout.isDrawerOpen(GravityCompat.START) && !state.drawerOpen)
            binding.drawerLayout.closeDrawer(GravityCompat.START)
        else if (!binding.drawerLayout.isDrawerVisible(GravityCompat.START) && state.drawerOpen)
            binding.drawerLayout.openDrawer(GravityCompat.START)

        when (state.syncing) {
            is SyncRepository.SyncProgress.Idle -> {
                binding.syncing.isVisible = false
                binding.snackbar.isVisible =
                    (!state.defaultSms ||
                        !state.smsPermission ||
                        !state.contactPermission ||
                        !state.notificationPermission)
            }

            is SyncRepository.SyncProgress.Running -> {
                binding.syncing.isVisible = true
                findViewById<ProgressBar>(R.id.syncingProgress)?.let { progress ->
                    progress.max = state.syncing.max
                    ObjectAnimator.ofInt(
                            progress,
                            "progress",
                            progress.progress,
                            state.syncing.progress,
                        )
                        .start()
                    progress.isIndeterminate = state.syncing.indeterminate
                }
                binding.snackbar.isVisible = false
            }
        }

        when {
            !state.defaultSms -> {
                (binding.snackbar as? ViewStub)?.findViewById<View>(R.id.snackbarTitle)?.let {
                    (it as? ir.pmessages.app.common.widget.QkTextView)?.setText(
                        R.string.main_default_sms_title
                    )
                }
                (binding.snackbar as? ViewStub)?.findViewById<View>(R.id.snackbarMessage)?.let {
                    (it as? ir.pmessages.app.common.widget.QkTextView)?.setText(
                        R.string.main_default_sms_message
                    )
                }
                (binding.snackbar as? ViewStub)?.findViewById<View>(R.id.snackbarButton)?.let {
                    (it as? ir.pmessages.app.common.widget.QkTextView)?.setText(
                        R.string.main_default_sms_change
                    )
                }
            }

            !state.smsPermission -> {
                (binding.snackbar as? ViewStub)?.findViewById<View>(R.id.snackbarTitle)?.let {
                    (it as? ir.pmessages.app.common.widget.QkTextView)?.setText(
                        R.string.main_permission_required
                    )
                }
                (binding.snackbar as? ViewStub)?.findViewById<View>(R.id.snackbarMessage)?.let {
                    (it as? ir.pmessages.app.common.widget.QkTextView)?.setText(
                        R.string.main_permission_sms
                    )
                }
                (binding.snackbar as? ViewStub)?.findViewById<View>(R.id.snackbarButton)?.let {
                    (it as? ir.pmessages.app.common.widget.QkTextView)?.setText(
                        R.string.main_permission_allow
                    )
                }
            }

            !state.contactPermission -> {
                (binding.snackbar as? ViewStub)?.findViewById<View>(R.id.snackbarTitle)?.let {
                    (it as? ir.pmessages.app.common.widget.QkTextView)?.setText(
                        R.string.main_permission_required
                    )
                }
                (binding.snackbar as? ViewStub)?.findViewById<View>(R.id.snackbarMessage)?.let {
                    (it as? ir.pmessages.app.common.widget.QkTextView)?.setText(
                        R.string.main_permission_contacts
                    )
                }
                (binding.snackbar as? ViewStub)?.findViewById<View>(R.id.snackbarButton)?.let {
                    (it as? ir.pmessages.app.common.widget.QkTextView)?.setText(
                        R.string.main_permission_allow
                    )
                }
            }

            !state.notificationPermission -> {
                (binding.snackbar as? ViewStub)?.findViewById<View>(R.id.snackbarTitle)?.let {
                    (it as? ir.pmessages.app.common.widget.QkTextView)?.setText(
                        R.string.main_permission_required
                    )
                }
                (binding.snackbar as? ViewStub)?.findViewById<View>(R.id.snackbarMessage)?.let {
                    (it as? ir.pmessages.app.common.widget.QkTextView)?.setText(
                        R.string.main_permission_notifications
                    )
                }
                (binding.snackbar as? ViewStub)?.findViewById<View>(R.id.snackbarButton)?.let {
                    (it as? ir.pmessages.app.common.widget.QkTextView)?.setText(
                        R.string.main_permission_allow
                    )
                }
            }
        }
    }

    override fun onResume() = super.onResume().also { activityResumedIntent.onNext(true) }

    override fun onPause() = super.onPause().also { activityResumedIntent.onNext(false) }

    override fun onDestroy() = super.onDestroy().also { disposables.dispose() }

    override fun showBackButton(show: Boolean) =
        toggle.let {
            it.onDrawerSlide(binding.drawer.root, if (show) 1f else 0f)
            it.drawerArrowDrawable.color =
                when (show) {
                    true -> resolveThemeColor(android.R.attr.textColorSecondary)
                    false -> resolveThemeColor(android.R.attr.textColorPrimary)
                }
        }

    override fun requestDefaultSms() = navigator.showDefaultSmsDialog(this)

    override fun restartActivity() {
        finish()
        startActivity(intent)
    }

    override fun requestPermissions() {
        val permissions =
            mutableListOf(
                Manifest.permission.READ_SMS,
                Manifest.permission.SEND_SMS,
                Manifest.permission.READ_CONTACTS,
            )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            permissions += Manifest.permission.POST_NOTIFICATIONS

        ActivityCompat.requestPermissions(this, permissions.toTypedArray(), 0)
    }

    override fun clearSearch() {
        dismissKeyboard()
        binding.toolbarSearch.text = null
        binding.clearSearch.isVisible = false
    }

    override fun clearSelection() = conversationsAdapter.clearSelection()

    override fun toggleSelectAll() = conversationsAdapter.toggleSelectAll()

    override fun themeChanged() = binding.recyclerView.scrapViews()

    override fun showBlockingDialog(conversations: List<Long>, block: Boolean) {
        blockingDialog.show(this, conversations, block)
    }

    override fun showDeleteDialog(conversations: List<Long>) {
        val dialog =
            AlertDialog.Builder(this, R.style.AppThemeDialog)
                .setTitle(R.string.dialog_delete_title)
                .setMessage(
                    resources.getQuantityString(
                        R.plurals.dialog_delete_message,
                        conversations.size,
                        conversations.size,
                    )
                )
                .setPositiveButton(R.string.button_delete) { _, _ ->
                    confirmDeleteIntent.onNext(conversations)
                }
                .setNegativeButton(R.string.button_cancel, null)
                .create()

        dialog.show()
    }

    override fun showRenameDialog(conversationName: String) =
        TextInputDialog(this, getString(R.string.info_name), renameConversationIntent::onNext)
            .setText(conversationName)
            .show()

    override fun showChangelog(changelog: ChangelogManager.CumulativeChangelog) =
        changelogDialog.show(changelog)

    override fun showArchivedSnackbar(countConversationsArchived: Int, isArchiving: Boolean) =
        Snackbar.make(
                binding.drawerLayout,
                if (isArchiving) {
                    resources.getQuantityString(
                        R.plurals.toast_archived,
                        countConversationsArchived,
                        countConversationsArchived,
                    )
                } else {
                    resources.getQuantityString(
                        R.plurals.toast_unarchived,
                        countConversationsArchived,
                        countConversationsArchived,
                    )
                },
                if (countConversationsArchived < 10) Snackbar.LENGTH_LONG
                else Snackbar.LENGTH_INDEFINITE,
            )
            .let {
                it.setAction(R.string.button_undo) { undoArchiveIntent.onNext(Unit) }
                it.setActionTextColor(colors.theme().theme)
                it.show()
            }

    // ---- Customisable categories (filter chips) ---------------------------------------------

    private var lastState: MainState? = null
    private var lastSelection: List<Long> = emptyList()
    private val customChips = mutableListOf<Chip>()
    private var addChip: Chip? = null

    private fun newChip(label: String): Chip =
        (layoutInflater.inflate(R.layout.main_category_chip, binding.filterGroup, false) as Chip)
            .apply {
                id = View.generateViewId()
                text = label
            }

    private fun rebuildChips() {
        listOf(
                Triple(CategoryStore.KEY_ALL, binding.filterAll, R.string.main_filter_all),
                Triple(CategoryStore.KEY_UNREAD, binding.filterUnread, R.string.main_filter_unread),
                Triple(CategoryStore.KEY_ARCHIVED, binding.filterArchived, R.string.drawer_archived),
            )
            .forEach { (key, chip, defaultRes) ->
                chip.text = categoryStore.builtinName(key, getString(defaultRes))
                chip.isVisible = !categoryStore.isBuiltinHidden(key)
                chip.setOnLongClickListener {
                    showBuiltinChipDialog(key, chip.text.toString())
                    true
                }
            }

        customChips.forEach { binding.filterGroup.removeView(it) }
        customChips.clear()
        addChip?.let { binding.filterGroup.removeView(it) }

        categoryStore.categories().forEach { category ->
            val chip = newChip(category.name)
            chip.tag = category.id
            chip.setOnClickListener { customCategorySelectedIntent.onNext(category.id) }
            chip.setOnLongClickListener {
                showCustomChipDialog(category)
                true
            }
            binding.filterGroup.addView(chip)
            customChips.add(chip)
        }

        val add = newChip("+ " + getString(R.string.category_new))
        add.isCheckable = false
        add.setOnClickListener { showNameDialog(getString(R.string.category_new), "") { name ->
            categoryStore.add(name)
            rebuildChips()
        } }
        binding.filterGroup.addView(add)
        addChip = add

        lastState?.let { updateChipChecks(it) }
    }

    private fun updateChipChecks(state: MainState) {
        binding.filterAll.isChecked = state.activeChip == MessageCategory.ALL
        binding.filterUnread.isChecked = state.activeChip == MessageCategory.UNREAD
        binding.filterArchived.isChecked = state.activeChip == MessageCategory.ARCHIVED
        customChips.forEach { chip ->
            chip.isChecked =
                state.activeChip == MessageCategory.CUSTOM && chip.tag == state.activeCategoryId
        }
    }

    private fun showNameDialog(title: String, initial: String, onSave: (String) -> Unit) {
        val input = EditText(this)
        input.setText(initial)
        input.setSingleLine(true)
        input.setSelection(input.text.length)
        input.hint = getString(R.string.category_name_hint)
        val container = FrameLayout(this)
        val margin = (20 * resources.displayMetrics.density).toInt()
        container.addView(
            input,
            FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                )
                .apply { setMargins(margin, margin / 2, margin, 0) },
        )
        AlertDialog.Builder(this, R.style.AppThemeDialog)
            .setTitle(title)
            .setView(container)
            .setPositiveButton(R.string.button_save) { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) onSave(name)
            }
            .setNegativeButton(R.string.button_cancel, null)
            .show()
    }

    private fun showBuiltinChipDialog(key: String, currentName: String) {
        val items =
            arrayOf(
                getString(R.string.category_rename),
                getString(R.string.category_hide),
                getString(R.string.category_restore_defaults),
            )
        AlertDialog.Builder(this, R.style.AppThemeDialog)
            .setItems(items) { _, which ->
                when (which) {
                    0 ->
                        showNameDialog(getString(R.string.category_rename), currentName) { name ->
                            categoryStore.setBuiltinName(key, name)
                            rebuildChips()
                        }
                    1 -> {
                        categoryStore.setBuiltinHidden(key, true)
                        val active = lastState?.activeChip
                        val wasActive =
                            (key == CategoryStore.KEY_ALL && active == MessageCategory.ALL) ||
                                (key == CategoryStore.KEY_UNREAD && active == MessageCategory.UNREAD) ||
                                (key == CategoryStore.KEY_ARCHIVED && active == MessageCategory.ARCHIVED)
                        rebuildChips()
                        if (wasActive) builtinFilterSubject.onNext(MessageCategory.ALL)
                    }
                    else -> {
                        categoryStore.resetBuiltins()
                        rebuildChips()
                    }
                }
            }
            .show()
    }

    private fun showCustomChipDialog(category: Category) {
        val items = arrayOf(getString(R.string.category_rename), getString(R.string.category_delete))
        AlertDialog.Builder(this, R.style.AppThemeDialog)
            .setItems(items) { _, which ->
                if (which == 0) {
                    showNameDialog(getString(R.string.category_rename), category.name) { name ->
                        categoryStore.rename(category.id, name)
                        rebuildChips()
                    }
                } else {
                    AlertDialog.Builder(this, R.style.AppThemeDialog)
                        .setMessage(R.string.category_delete_confirm)
                        .setPositiveButton(R.string.button_delete) { _, _ ->
                            val wasActive =
                                lastState?.activeChip == MessageCategory.CUSTOM &&
                                    lastState?.activeCategoryId == category.id
                            categoryStore.delete(category.id)
                            rebuildChips()
                            if (wasActive) builtinFilterSubject.onNext(MessageCategory.ALL)
                        }
                        .setNegativeButton(R.string.button_cancel, null)
                        .show()
                }
            }
            .show()
    }

    private fun refreshActiveCategory() {
        val state = lastState ?: return
        val id = state.activeCategoryId
        if (state.activeChip == MessageCategory.CUSTOM && id != null) {
            customCategorySelectedIntent.onNext(id)
        }
    }

    private fun showAddToCategoryDialog(threadIds: List<Long>) {
        if (threadIds.isEmpty()) return
        val categories = categoryStore.categories()

        val createAndAdd = {
            showNameDialog(getString(R.string.category_new), "") { name ->
                categoryStore.add(name, threadIds)
                rebuildChips()
                conversationsAdapter.clearSelection()
            }
        }

        if (categories.isEmpty()) {
            createAndAdd()
            return
        }

        val checked = BooleanArray(categories.size) { i -> categories[i].threadIds.containsAll(threadIds) }
        val original = checked.copyOf()
        AlertDialog.Builder(this, R.style.AppThemeDialog)
            .setTitle(R.string.category_add_to)
            .setMultiChoiceItems(categories.map { it.name }.toTypedArray(), checked) { _, which, isChecked ->
                checked[which] = isChecked
            }
            .setPositiveButton(R.string.button_save) { _, _ ->
                categories.forEachIndexed { i, category ->
                    if (checked[i] != original[i]) {
                        categoryStore.setMembership(category.id, threadIds, checked[i])
                    }
                }
                conversationsAdapter.clearSelection()
                refreshActiveCategory()
            }
            .setNeutralButton(R.string.category_new) { _, _ -> createAndAdd() }
            .setNegativeButton(R.string.button_cancel, null)
            .show()
    }

    override fun onCreateOptionsMenu(menu: Menu?) =
        menu?.let {
            menuInflater.inflate(R.menu.main, it)
            super.onCreateOptionsMenu(it)
        } ?: false

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.category) {
            showAddToCategoryDialog(lastSelection)
            return true
        }
        optionsItemIntent.onNext(item.itemId)
        return true
    }

    override fun onBackPressed() = backPressedSubject.onNext(NavItem.BACK)

    override fun drawerToggled(opened: Boolean) {
        if (opened) {
            dismissKeyboard()
            if (!binding.drawer.inbox.isInTouchMode) binding.drawer.inbox.requestFocus()
        } else binding.toolbarSearch.requestFocus()
    }

    private fun showDrawerMenu() {
        val popup = PopupMenu(this, binding.cVTopBar3, Gravity.END, 0, R.style.DrawerPopupMenu)
        popup.menuInflater.inflate(R.menu.drawer_menu, popup.menu)

        try {
            val fieldMPopup = PopupMenu::class.java.getDeclaredField("mPopup")
            fieldMPopup.isAccessible = true
            val mPopup = fieldMPopup.get(popup)
            mPopup.javaClass
                .getDeclaredMethod("setForceShowIcon", Boolean::class.java)
                .invoke(mPopup, true)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        val iconColor = resolveThemeColor(android.R.attr.textColorPrimary)
        for (i in 0 until popup.menu.size) {
            val menuItem = popup.menu[i]
            menuItem.icon?.setTint(iconColor)
        }

        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.menu_backup -> {
                    backPressedSubject.onNext(NavItem.BACKUP)
                    true
                }

                R.id.menu_scheduled -> {
                    backPressedSubject.onNext(NavItem.SCHEDULED)
                    true
                }

                R.id.menu_blocking -> {
                    backPressedSubject.onNext(NavItem.BLOCKING)
                    true
                }

                R.id.menu_settings -> {
                    backPressedSubject.onNext(NavItem.SETTINGS)
                    true
                }

                //                R.id.menu_invite -> {
                //                    backPressedSubject.onNext(NavItem.INVITE)
                //                    true
                //                }

                else -> false
            }
        }

        popup.show()
    }
}
