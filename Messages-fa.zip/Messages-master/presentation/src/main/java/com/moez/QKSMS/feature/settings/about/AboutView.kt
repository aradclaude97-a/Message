/*
 * SPDX-FileCopyrightText: 2018 Moez Bhatti <moez.bhatti@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.feature.settings.about

import io.reactivex.Observable
import ir.pmessages.app.common.base.QkViewContract
import ir.pmessages.app.common.widget.PreferenceView

interface AboutView : QkViewContract<Unit> {

    fun preferenceClicks(): Observable<PreferenceView>
}
