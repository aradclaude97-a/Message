/*
 * SPDX-FileCopyrightText: 2018 Moez Bhatti <moez.bhatti@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.feature.blocking.filters

import io.reactivex.Observable
import ir.pmessages.app.common.base.QkViewContract
import ir.pmessages.app.model.MessageContentFilterData

interface MessageContentFiltersView : QkViewContract<MessageContentFiltersState> {

    fun removeFilter(): Observable<Long>

    fun addFilter(): Observable<*>

    fun saveFilter(): Observable<MessageContentFilterData>

    fun showAddDialog()
}
