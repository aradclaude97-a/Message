/*
 * SPDX-FileCopyrightText: 2018 Moez Bhatti <moez.bhatti@gmail.com>
 * SPDX-FileCopyrightText: Saalim Quadri <danascape@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.feature.plus

import android.graphics.Typeface
import android.os.Bundle
import androidx.core.view.children
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.jakewharton.rxbinding2.view.clicks
import dagger.android.AndroidInjection
import javax.inject.Inject
import kotlinx.coroutines.launch
import ir.pmessages.app.R
import ir.pmessages.app.common.base.QkThemedActivity
import ir.pmessages.app.common.util.FontProvider
import ir.pmessages.app.common.util.extensions.makeToast
import ir.pmessages.app.common.util.extensions.resolveThemeColor
import ir.pmessages.app.common.util.extensions.setBackgroundTint
import ir.pmessages.app.common.util.extensions.setTint
import ir.pmessages.app.common.util.extensions.setVisible
import ir.pmessages.app.common.widget.PreferenceView
import ir.pmessages.app.databinding.QksmsPlusActivityBinding
import ir.pmessages.app.feature.plus.experiment.UpgradeButtonExperiment
import ir.pmessages.app.manager.BillingManager
import timber.log.Timber

class PlusActivity :
    QkThemedActivity<QksmsPlusActivityBinding>(QksmsPlusActivityBinding::inflate), PlusView {

    @Inject lateinit var fontProvider: FontProvider
    @Inject lateinit var upgradeButtonExperiment: UpgradeButtonExperiment
    @Inject lateinit var viewModelFactory: ViewModelProvider.Factory

    private val viewModel by lazy {
        ViewModelProvider(this, viewModelFactory)[PlusViewModel::class.java]
    }

    override val upgradeIntent
        get() = binding.upgrade.clicks()

    override val upgradeDonateIntent
        get() = binding.upgradeDonate.clicks()

    override val donateIntent
        get() = binding.donate.clicks()

    override val themeClicks
        get() = binding.themes.clicks()

    override val scheduleClicks
        get() = binding.schedule.clicks()

    override val backupClicks
        get() = binding.backup.clicks()

    override val delayedClicks
        get() = binding.delayed.clicks()

    override val nightClicks
        get() = binding.night.clicks()

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setTitle(R.string.title_qksms_plus)
        showBackButton(true)
        viewModel.bindView(this)

        binding.free.setVisible(false)

        if (!prefs.systemFont.get()) {
            fontProvider.getLato { lato ->
                val typeface = Typeface.create(lato, Typeface.BOLD)
                binding.toolbarLayout.collapsingToolbar.setCollapsedTitleTypeface(typeface)
                binding.toolbarLayout.collapsingToolbar.setExpandedTitleTypeface(typeface)
            }
        }

        // Make the list titles bold
        binding.linearLayout.children
            .mapNotNull { it as? PreferenceView }
            .map { it.titleTextView }
            .forEach { it.setTypeface(it.typeface, Typeface.BOLD) }

        val textPrimary = resolveThemeColor(android.R.attr.textColorPrimary)
        binding.toolbarLayout.collapsingToolbar.setCollapsedTitleTextColor(textPrimary)
        binding.toolbarLayout.collapsingToolbar.setExpandedTitleColor(textPrimary)

        val theme = colors.theme().theme
        binding.donate.setBackgroundTint(theme)
        binding.upgrade.setBackgroundTint(theme)
        binding.thanksIcon.setTint(theme)
    }

    override fun render(state: PlusState) {
        binding.description.text =
            getString(R.string.qksms_plus_description_summary, state.upgradePrice)
        binding.upgrade.text =
            getString(upgradeButtonExperiment.variant, state.upgradePrice, state.currency)
        binding.upgradeDonate.text =
            getString(R.string.qksms_plus_upgrade_donate, state.upgradeDonatePrice, state.currency)

        val fdroid = true

        binding.free.setVisible(fdroid)
        binding.toUpgrade.setVisible(!fdroid && !state.upgraded)
        binding.upgraded.setVisible(!fdroid && state.upgraded)

        binding.themes.isEnabled = state.upgraded
        binding.schedule.isEnabled = state.upgraded
        binding.backup.isEnabled = state.upgraded
        binding.delayed.isEnabled = state.upgraded
        binding.night.isEnabled = state.upgraded
    }

    override fun initiatePurchaseFlow(billingManager: BillingManager, sku: String) {
        lifecycleScope.launch {
            try {
                billingManager.initiatePurchaseFlow(this@PlusActivity, sku)
            } catch (e: Exception) {
                Timber.w(e)
                makeToast(R.string.qksms_plus_error)
            }
        }
    }
}
