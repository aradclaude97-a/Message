/*
 * SPDX-FileCopyrightText: 2017 Moez Bhatti <moez.bhatti@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.injection

import dagger.Component
import dagger.android.support.AndroidSupportInjectionModule
import javax.inject.Singleton
import ir.pmessages.app.common.QKApplication
import ir.pmessages.app.common.QkDialog
import ir.pmessages.app.common.util.QkChooserTargetService
import ir.pmessages.app.common.widget.AvatarView
import ir.pmessages.app.common.widget.PagerTitleView
import ir.pmessages.app.common.widget.PreferenceView
import ir.pmessages.app.common.widget.QkEditText
import ir.pmessages.app.common.widget.QkSwitch
import ir.pmessages.app.common.widget.QkTextView
import ir.pmessages.app.common.widget.RadioPreferenceView
import ir.pmessages.app.feature.backup.BackupController
import ir.pmessages.app.feature.blocking.BlockingController
import ir.pmessages.app.feature.blocking.filters.MessageContentFiltersController
import ir.pmessages.app.feature.blocking.manager.BlockingManagerController
import ir.pmessages.app.feature.blocking.messages.BlockedMessagesController
import ir.pmessages.app.feature.blocking.numbers.BlockedNumbersController
import ir.pmessages.app.feature.compose.editing.DetailedChipView
import ir.pmessages.app.feature.conversationinfo.injection.ConversationInfoComponent
import ir.pmessages.app.feature.settings.SettingsController
import ir.pmessages.app.feature.settings.about.AboutController
import ir.pmessages.app.feature.settings.swipe.SwipeActionsController
import ir.pmessages.app.feature.themepicker.injection.ThemePickerComponent
import ir.pmessages.app.feature.widget.WidgetAdapter
import ir.pmessages.app.injection.android.ActivityBuilderModule
import ir.pmessages.app.injection.android.BroadcastReceiverBuilderModule
import ir.pmessages.app.injection.android.ServiceBuilderModule

@Singleton
@Component(
    modules =
        [
            AndroidSupportInjectionModule::class,
            AppModule::class,
            ActivityBuilderModule::class,
            BroadcastReceiverBuilderModule::class,
            ServiceBuilderModule::class,
        ]
)
interface AppComponent {

    fun conversationInfoBuilder(): ConversationInfoComponent.Builder

    fun themePickerBuilder(): ThemePickerComponent.Builder

    fun inject(application: QKApplication)

    fun inject(controller: AboutController)

    fun inject(controller: BackupController)

    fun inject(controller: BlockedMessagesController)

    fun inject(controller: BlockedNumbersController)

    fun inject(controller: MessageContentFiltersController)

    fun inject(controller: BlockingController)

    fun inject(controller: BlockingManagerController)

    fun inject(controller: SettingsController)

    fun inject(controller: SwipeActionsController)

    fun inject(dialog: QkDialog)

    fun inject(service: WidgetAdapter)

    /** This can't use AndroidInjection, or else it will crash on pre-marshmallow devices */
    fun inject(service: QkChooserTargetService)

    fun inject(view: AvatarView)

    fun inject(view: DetailedChipView)

    fun inject(view: PagerTitleView)

    fun inject(view: PreferenceView)

    fun inject(view: RadioPreferenceView)

    fun inject(view: QkEditText)

    fun inject(view: QkSwitch)

    fun inject(view: QkTextView)
}
