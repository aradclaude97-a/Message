/*
 * SPDX-FileCopyrightText: 2018 Moez Bhatti <moez.bhatti@gmail.com>
 * SPDX-FileCopyrightText: Saalim Quadri <danascape@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.feature.gallery

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import com.google.android.mms.ContentType
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import java.util.Collections
import java.util.WeakHashMap
import javax.inject.Inject
import ir.pmessages.app.R
import ir.pmessages.app.common.base.QkRealmAdapter
import ir.pmessages.app.common.base.QkViewHolder
import ir.pmessages.app.databinding.GalleryImagePageBinding
import ir.pmessages.app.databinding.GalleryVideoPageBinding
import ir.pmessages.app.extensions.isImage
import ir.pmessages.app.extensions.isVideo
import ir.pmessages.app.model.MmsPart
import ir.pmessages.app.util.GlideApp

class GalleryPagerAdapter @Inject constructor(private val context: Context) :
    QkRealmAdapter<MmsPart, QkViewHolder>() {

    companion object {
        private const val VIEW_TYPE_INVALID = 0
        private const val VIEW_TYPE_IMAGE = 1
        private const val VIEW_TYPE_VIDEO = 2
    }

    val clicks: Subject<View> = PublishSubject.create()

    private val contentResolver = context.contentResolver
    private val exoPlayers = Collections.newSetFromMap(WeakHashMap<ExoPlayer?, Boolean>())

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): QkViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return QkViewHolder(
            when (viewType) {
                VIEW_TYPE_IMAGE -> {
                    val binding = GalleryImagePageBinding.inflate(inflater, parent, false)
                    // Use a tiny offset for midScale since setScaleLevels requires min < mid < max
                    binding.image.attacher.setScaleLevels(1f, 1.01f, 3f)
                    binding.root.apply { setOnClickListener(clicks::onNext) }
                }

                VIEW_TYPE_VIDEO -> {
                    val binding = GalleryVideoPageBinding.inflate(inflater, parent, false)
                    binding.root.apply { setOnClickListener(clicks::onNext) }
                }

                else ->
                    inflater.inflate(R.layout.gallery_invalid_page, parent, false).apply {
                        setOnClickListener(clicks::onNext)
                    }
            }
        )
    }

    override fun onBindViewHolder(holder: QkViewHolder, position: Int) {
        val part = getItem(position) ?: return
        when (getItemViewType(position)) {
            VIEW_TYPE_IMAGE -> {
                val binding = GalleryImagePageBinding.bind(holder.containerView)
                // We need to explicitly request a gif from glide for animations to work
                when (part.getUri().let(contentResolver::getType)) {
                    ContentType.IMAGE_GIF ->
                        GlideApp.with(context).asGif().load(part.getUri()).into(binding.image)

                    else ->
                        GlideApp.with(context).asBitmap().load(part.getUri()).into(binding.image)
                }
            }

            VIEW_TYPE_VIDEO -> {
                val binding = GalleryVideoPageBinding.bind(holder.containerView)
                val exoPlayer = ExoPlayer.Builder(context).build()
                binding.video.player = exoPlayer
                exoPlayers.add(exoPlayer)

                val mediaItem = MediaItem.fromUri(part.getUri())
                exoPlayer.setMediaItem(mediaItem)
                exoPlayer.prepare()
            }
        }
    }

    override fun getItemViewType(position: Int): Int {
        val part = getItem(position)
        return when {
            part?.isImage() == true -> VIEW_TYPE_IMAGE
            part?.isVideo() == true -> VIEW_TYPE_VIDEO
            else -> VIEW_TYPE_INVALID
        }
    }

    fun destroy() {
        exoPlayers.forEach { exoPlayer -> exoPlayer?.release() }
    }
}
