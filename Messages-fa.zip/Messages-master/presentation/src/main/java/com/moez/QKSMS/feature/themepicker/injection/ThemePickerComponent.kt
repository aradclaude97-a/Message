/*
 * SPDX-FileCopyrightText: 2018 Moez Bhatti <moez.bhatti@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.feature.themepicker.injection

import dagger.Subcomponent
import ir.pmessages.app.feature.themepicker.ThemePickerController
import ir.pmessages.app.injection.scope.ControllerScope

@ControllerScope
@Subcomponent(modules = [ThemePickerModule::class])
interface ThemePickerComponent {

    fun inject(controller: ThemePickerController)

    @Subcomponent.Builder
    interface Builder {
        fun themePickerModule(module: ThemePickerModule): Builder

        fun build(): ThemePickerComponent
    }
}
