/*
 * SPDX-FileCopyrightText: 2017 Moez Bhatti <moez.bhatti@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.feature.gallery

import io.reactivex.Observable
import ir.pmessages.app.common.base.QkView
import ir.pmessages.app.model.MmsPart

interface GalleryView : QkView<GalleryState> {

    fun optionsItemSelected(): Observable<Int>

    fun screenTouched(): Observable<*>

    fun pageChanged(): Observable<MmsPart>

    fun requestStoragePermission()
}
