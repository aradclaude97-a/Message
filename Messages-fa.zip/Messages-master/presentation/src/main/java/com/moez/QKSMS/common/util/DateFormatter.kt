/*
 * SPDX-FileCopyrightText: 2017 Moez Bhatti <moez.bhatti@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.common.util

import android.content.Context
import android.text.format.DateFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton
import ir.pmessages.app.common.util.extensions.isSameDay
import ir.pmessages.app.common.util.extensions.isSameWeek
import ir.pmessages.app.common.util.extensions.isSameYear

@Singleton
class DateFormatter @Inject constructor(val context: Context) {

    private val jalali: Boolean
        get() = JalaliCalendar.isActive()

    /**
     * Formats the [pattern] correctly for the current locale, and replaces 12 hour format with 24
     * hour format if necessary
     */
    private fun getFormatter(pattern: String): SimpleDateFormat {
        var formattedPattern = DateFormat.getBestDateTimePattern(Locale.getDefault(), pattern)

        if (DateFormat.is24HourFormat(context)) {
            formattedPattern =
                formattedPattern
                    .replace("h", "HH")
                    .replace("K", "HH")
                    .replace("\\s+a".toRegex(), "")
        }

        return SimpleDateFormat(formattedPattern, Locale.getDefault())
    }

    // ---- Jalali helpers -------------------------------------------------------------------

    private fun cal(date: Long): Calendar =
        Calendar.getInstance().apply { timeInMillis = date }

    private fun jTime(c: Calendar, withSeconds: Boolean = false): String {
        val minute = c.get(Calendar.MINUTE).toString().padStart(2, '0')
        val second = c.get(Calendar.SECOND).toString().padStart(2, '0')
        val text =
            if (DateFormat.is24HourFormat(context)) {
                val h = c.get(Calendar.HOUR_OF_DAY).toString().padStart(2, '0')
                if (withSeconds) "$h:$minute:$second" else "$h:$minute"
            } else {
                var h = c.get(Calendar.HOUR)
                if (h == 0) h = 12
                val suffix = if (c.get(Calendar.AM_PM) == Calendar.AM) "ق.ظ" else "ب.ظ"
                if (withSeconds) "$h:$minute:$second $suffix" else "$h:$minute $suffix"
            }
        return JalaliCalendar.toPersianDigits(text)
    }

    private fun jWeekday(c: Calendar) = JalaliCalendar.weekdayNames[c.get(Calendar.DAY_OF_WEEK) - 1]

    private fun jDayMonth(c: Calendar): String {
        val d = JalaliCalendar.fromCalendar(c)
        return JalaliCalendar.toPersianDigits(d.day) + " " + JalaliCalendar.monthNames[d.month - 1]
    }

    private fun jFull(c: Calendar): String {
        val d = JalaliCalendar.fromCalendar(c)
        return jDayMonth(c) + " " + JalaliCalendar.toPersianDigits(d.year)
    }

    private fun jNumeric(c: Calendar): String {
        val d = JalaliCalendar.fromCalendar(c)
        val text =
            "${d.year}/${d.month.toString().padStart(2, '0')}/${d.day.toString().padStart(2, '0')}"
        return JalaliCalendar.toPersianDigits(text)
    }

    private fun sameJalaliYear(a: Calendar, b: Calendar) =
        JalaliCalendar.fromCalendar(a).year == JalaliCalendar.fromCalendar(b).year

    // ---- Public API ------------------------------------------------------------------------

    fun getDetailedTimestamp(date: Long): String {
        if (jalali) {
            val c = cal(date)
            return jNumeric(c) + "، " + jTime(c, withSeconds = true)
        }
        return getFormatter("M/d/y, h:mm:ss a").format(date)
    }

    fun getTimestamp(date: Long): String {
        if (jalali) return jTime(cal(date))
        return getFormatter("h:mm a").format(date)
    }

    fun getMessageTimestamp(date: Long): String {
        val now = Calendar.getInstance()
        val then = cal(date)

        if (jalali) {
            return when {
                now.isSameDay(then) -> jTime(then)
                now.isSameWeek(then) -> jWeekday(then) + "، " + jTime(then)
                sameJalaliYear(now, then) -> jDayMonth(then) + "، " + jTime(then)
                else -> jFull(then) + "، " + jTime(then)
            }
        }

        return when {
            now.isSameDay(then) -> getFormatter("h:mm a")
            now.isSameWeek(then) -> getFormatter("E h:mm a")
            now.isSameYear(then) -> getFormatter("MMM d, h:mm a")
            else -> getFormatter("MMM d yyyy, h:mm a")
        }.format(date)
    }

    fun getConversationTimestamp(date: Long): String {
        val now = Calendar.getInstance()
        val then = cal(date)

        if (jalali) {
            return when {
                now.isSameDay(then) -> jTime(then)
                now.isSameWeek(then) -> jWeekday(then)
                sameJalaliYear(now, then) -> jDayMonth(then)
                else -> jNumeric(then)
            }
        }

        return when {
            now.isSameDay(then) -> getFormatter("h:mm a")
            now.isSameWeek(then) -> getFormatter("E")
            now.isSameYear(then) -> getFormatter("MMM d")
            else -> getFormatter("MM/d/yy")
        }.format(date)
    }

    fun getScheduledTimestamp(date: Long): String {
        val now = Calendar.getInstance()
        val then = cal(date)

        if (jalali) {
            return when {
                now.isSameDay(then) -> jTime(then)
                sameJalaliYear(now, then) -> jDayMonth(then) + " " + jTime(then)
                else -> jFull(then) + " " + jTime(then)
            }
        }

        return when {
            now.isSameDay(then) -> getFormatter("h:mm a")
            now.isSameYear(then) -> getFormatter("MMM d h:mm a")
            else -> getFormatter("MMM d yyyy h:mm a")
        }.format(date)
    }
}
