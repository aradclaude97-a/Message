/*
 * SPDX-FileCopyrightText: 2019 Moez Bhatti <moez.bhatti@gmail.com>
 * SPDX-FileCopyrightText: Saalim Quadri <danascape@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.common.widget

import android.content.Context
import android.content.res.ColorStateList
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import javax.inject.Inject
import ir.pmessages.app.R
import ir.pmessages.app.common.util.Colors
import ir.pmessages.app.common.util.extensions.forwardTouches
import ir.pmessages.app.common.util.extensions.resolveThemeAttribute
import ir.pmessages.app.common.util.extensions.resolveThemeColor
import ir.pmessages.app.common.util.extensions.setVisible
import ir.pmessages.app.databinding.RadioPreferenceViewBinding
import ir.pmessages.app.injection.appComponent

class RadioPreferenceView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) :
    ConstraintLayout(context, attrs) {

    @Inject lateinit var colors: Colors
    private var layout: RadioPreferenceViewBinding

    val radioButton
        get() = layout.radioButton

    val titleView
        get() = layout.titleView

    val summaryView
        get() = layout.summaryView

    var title: String? = null
        set(value) {
            field = value

            if (isInEditMode) {
                findViewById<TextView>(R.id.titleView).text = value
            } else {
                layout.titleView.text = value
            }
        }

    var summary: String? = null
        set(value) {
            field = value

            if (isInEditMode) {
                findViewById<TextView>(R.id.summaryView).run {
                    text = value
                    setVisible(value?.isNotEmpty() == true)
                }
            } else {
                layout.summaryView.text = value
                layout.summaryView.setVisible(value?.isNotEmpty() == true)
            }
        }

    init {
        if (!isInEditMode) {
            appComponent.inject(this)
        }

        layout = RadioPreferenceViewBinding.inflate(LayoutInflater.from(context), this)
        setBackgroundResource(context.resolveThemeAttribute(R.attr.selectableItemBackground))

        val states =
            arrayOf(
                intArrayOf(android.R.attr.state_checked),
                intArrayOf(-android.R.attr.state_checked),
            )

        val themeColor =
            when (isInEditMode) {
                true -> context.resources.getColor(R.color.tools_theme)
                false -> colors.theme().theme
            }
        val textSecondary = context.resolveThemeColor(android.R.attr.textColorTertiary)
        layout.radioButton.buttonTintList =
            ColorStateList(states, intArrayOf(themeColor, textSecondary))
        layout.radioButton.forwardTouches(this)

        context.obtainStyledAttributes(attrs, R.styleable.RadioPreferenceView)?.run {
            title = getString(R.styleable.RadioPreferenceView_title)
            summary = getString(R.styleable.RadioPreferenceView_summary)

            // If there's a custom view used for the preference's widget, inflate it
            getResourceId(R.styleable.RadioPreferenceView_widget, -1)
                .takeIf { it != -1 }
                ?.let { id -> View.inflate(context, id, layout.widgetFrame) }

            recycle()
        }
    }
}
