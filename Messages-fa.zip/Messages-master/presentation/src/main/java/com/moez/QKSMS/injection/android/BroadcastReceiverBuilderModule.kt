/*
 * SPDX-FileCopyrightText: 2018 Moez Bhatti <moez.bhatti@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.injection.android

import dagger.Module
import dagger.android.ContributesAndroidInjector
import ir.pmessages.app.feature.widget.WidgetProvider
import ir.pmessages.app.injection.scope.ActivityScope
import ir.pmessages.app.receiver.BlockThreadReceiver
import ir.pmessages.app.receiver.BootReceiver
import ir.pmessages.app.receiver.DefaultSmsChangedReceiver
import ir.pmessages.app.receiver.DeleteConfirmationReceiver
import ir.pmessages.app.receiver.DeleteMessagesReceiver
import ir.pmessages.app.receiver.MarkArchivedReceiver
import ir.pmessages.app.receiver.MarkReadReceiver
import ir.pmessages.app.receiver.MarkSeenReceiver
import ir.pmessages.app.receiver.MmsReceivedReceiver
import ir.pmessages.app.receiver.MmsReceiver
import ir.pmessages.app.receiver.MmsSentReceiver
import ir.pmessages.app.receiver.MmsUpdatedReceiver
import ir.pmessages.app.receiver.NightModeReceiver
import ir.pmessages.app.receiver.RemoteMessagingReceiver
import ir.pmessages.app.receiver.SendScheduledMessageReceiver
import ir.pmessages.app.receiver.SmsDeliveredReceiver
import ir.pmessages.app.receiver.SmsProviderChangedReceiver
import ir.pmessages.app.receiver.SmsReceiver
import ir.pmessages.app.receiver.SmsSentReceiver
import ir.pmessages.app.receiver.SpeakThreadsReceiver
import ir.pmessages.app.receiver.StartActivityFromWidgetReceiver

@Module
abstract class BroadcastReceiverBuilderModule {

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindBlockThreadReceiver(): BlockThreadReceiver

    @ActivityScope @ContributesAndroidInjector() abstract fun bindBootReceiver(): BootReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindDefaultSmsChangedReceiver(): DefaultSmsChangedReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindDeleteMessagesReceiver(): DeleteMessagesReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindDeleteConfirmationReceiver(): DeleteConfirmationReceiver

    @ActivityScope
    @ContributesAndroidInjector
    abstract fun bindMarkArchivedReceiver(): MarkArchivedReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindMarkReadReceiver(): MarkReadReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindSpeakThreadsReceiver(): SpeakThreadsReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindStartActivityFromWidgetReceiver(): StartActivityFromWidgetReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindMarkSeenReceiver(): MarkSeenReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindMmsReceivedReceiver(): MmsReceivedReceiver

    @ActivityScope @ContributesAndroidInjector() abstract fun bindMmsReceiver(): MmsReceiver

    @ActivityScope @ContributesAndroidInjector() abstract fun bindMmsSentReceiver(): MmsSentReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindMmsUpdatedReceiver(): MmsUpdatedReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindNightModeReceiver(): NightModeReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindRemoteMessagingReceiver(): RemoteMessagingReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindSendScheduledMessageReceiver(): SendScheduledMessageReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindSmsDeliveredReceiver(): SmsDeliveredReceiver

    @ActivityScope
    @ContributesAndroidInjector()
    abstract fun bindSmsProviderChangedReceiver(): SmsProviderChangedReceiver

    @ActivityScope @ContributesAndroidInjector() abstract fun bindSmsReceiver(): SmsReceiver

    @ActivityScope @ContributesAndroidInjector() abstract fun bindSmsSentReceiver(): SmsSentReceiver

    @ActivityScope @ContributesAndroidInjector() abstract fun bindWidgetProvider(): WidgetProvider
}
