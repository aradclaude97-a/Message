/*
 * SPDX-FileCopyrightText: 2019 Moez Bhatti <moez.bhatti@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.feature.blocking

import android.content.Context
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDispose
import io.reactivex.rxkotlin.plusAssign
import javax.inject.Inject
import ir.pmessages.app.R
import ir.pmessages.app.blocking.BlockingClient
import ir.pmessages.app.common.base.QkPresenter
import ir.pmessages.app.util.Preferences

class BlockingPresenter
@Inject
constructor(
    context: Context,
    private val blockingClient: BlockingClient,
    private val prefs: Preferences,
) : QkPresenter<BlockingView, BlockingState>(BlockingState()) {

    init {
        disposables +=
            prefs.blockingManager
                .asObservable()
                .map { client ->
                    when (client) {
                        Preferences.BLOCKING_MANAGER_CB ->
                            R.string.blocking_manager_call_blocker_title
                        Preferences.BLOCKING_MANAGER_CC ->
                            R.string.blocking_manager_call_control_title
                        Preferences.BLOCKING_MANAGER_SIA -> R.string.blocking_manager_sia_title
                        else -> R.string.app_name
                    }
                }
                .map(context::getString)
                .subscribe { manager -> newState { copy(blockingManager = manager) } }

        disposables +=
            prefs.drop.asObservable().subscribe { enabled ->
                newState { copy(dropEnabled = enabled) }
            }
    }

    override fun bindIntents(view: BlockingView) {
        super.bindIntents(view)

        view.blockingManagerIntent.autoDispose(view.scope()).subscribe {
            view.openBlockingManager()
        }

        view.blockedNumbersIntent.autoDispose(view.scope()).subscribe {
            if (prefs.blockingManager.get() == Preferences.BLOCKING_MANAGER_QKSMS) {
                // TODO: This is a hack, get rid of it once we implement AndroidX navigation
                view.openBlockedNumbers()
            } else {
                blockingClient.openSettings()
            }
        }

        view.messageContentFiltersIntent.autoDispose(view.scope()).subscribe {
            view.openMessageContentFilters()
        }

        view.blockedMessagesIntent.autoDispose(view.scope()).subscribe {
            view.openBlockedMessages()
        }

        view.dropClickedIntent.autoDispose(view.scope()).subscribe {
            prefs.drop.set(!prefs.drop.get())
        }
    }
}
