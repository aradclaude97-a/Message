/*
 * SPDX-FileCopyrightText: 2018 Moez Bhatti <moez.bhatti@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.common.util

import android.annotation.TargetApi
import android.content.Context
import android.content.Intent
import android.content.pm.ShortcutManager
import android.os.Build
import androidx.core.app.Person
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import javax.inject.Inject
import me.leolin.shortcutbadger.ShortcutBadger
import ir.pmessages.app.common.util.extensions.getThemedIcon
import ir.pmessages.app.common.util.extensions.toPerson
import ir.pmessages.app.feature.compose.ComposeActivity
import ir.pmessages.app.model.Conversation
import ir.pmessages.app.repository.ConversationRepository
import ir.pmessages.app.repository.MessageRepository
import timber.log.Timber

class ShortcutManagerImpl
@Inject
constructor(
    private val context: Context,
    private val conversationRepo: ConversationRepository,
    private val messageRepo: MessageRepository,
    private val colors: Colors,
) : ir.pmessages.app.manager.ShortcutManager {

    override fun updateBadge() {
        val count = messageRepo.getUnreadCount().toInt()
        ShortcutBadger.applyCount(context, count)
    }

    override fun updateShortcuts() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
            val shortcutManager =
                context.getSystemService(Context.SHORTCUT_SERVICE) as ShortcutManager
            if (shortcutManager.isRateLimitingActive) return

            val shortcuts: List<ShortcutInfoCompat> =
                conversationRepo
                    .getTopConversations()
                    .take(
                        shortcutManager.maxShortcutCountPerActivity -
                            shortcutManager.manifestShortcuts.size
                    )
                    .map { conversation -> createShortcutForConversation(conversation) }

            ShortcutManagerCompat.setDynamicShortcuts(context, shortcuts)
        }
    }

    /** Get the shortcut for a threadId. Will create it if it doesn't exist. */
    override fun getShortcut(threadId: Long): ShortcutInfoCompat? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
            var sc = getShortcuts().find { it.id == threadId.toString() }
            if (sc != null) sc = updateShortcut(sc)
            if (sc == null) {
                val conv = conversationRepo.getConversation(threadId)
                if (conv == null) return null else sc = createShortcutForConversation(conv)
            }
            return sc
        } else {
            return null
        }
    }

    /** Report thread usage. Will create the shortcut if it doesn't exist. */
    override fun reportShortcutUsed(threadId: Long) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
            val shortcutManager =
                context.getSystemService(Context.SHORTCUT_SERVICE) as ShortcutManager
            if (getShortcut(threadId) == null) {
                val conversation = conversationRepo.getOrCreateConversation(threadId)
                if (conversation == null) return
                val shortcut = createShortcutForConversation(conversation)
                ShortcutManagerCompat.setDynamicShortcuts(context, listOf(shortcut))
            }
            shortcutManager.reportShortcutUsed(threadId.toString())
        }
    }

    @TargetApi(29)
    private fun createShortcutForConversation(conversation: Conversation): ShortcutInfoCompat {
        Timber.v("creating shortcut for conversation ${conversation.id}")
        val icon =
            when {
                conversation.recipients.size == 1 -> {
                    val recipient = conversation.recipients.first()!!
                    recipient.getThemedIcon(
                        context,
                        colors.theme(recipient),
                        ShortcutManagerCompat.getIconMaxWidth(context),
                        ShortcutManagerCompat.getIconMaxHeight(context),
                    )
                }

                else -> {
                    conversation.getThemedIcon(
                        context,
                        ShortcutManagerCompat.getIconMaxWidth(context),
                        ShortcutManagerCompat.getIconMaxHeight(context),
                    )
                }
            }

        val persons: Array<Person> =
            conversation.recipients.map { it -> it.toPerson(context, colors) }.toTypedArray()

        val intent =
            Intent(context, ComposeActivity::class.java)
                .setAction(Intent.ACTION_VIEW)
                .putExtra("threadId", conversation.id)
                .putExtra("fromShortcut", true)

        val sc =
            ShortcutInfoCompat.Builder(context, "${conversation.id}")
                .setShortLabel(conversation.getTitle())
                .setLongLabel(conversation.getTitle())
                .setIcon(icon)
                .setIntent(intent)
                .setPersons(persons)
                .setLongLived(true)
                .build()

        ShortcutManagerCompat.pushDynamicShortcut(context, sc)
        return sc
    }

    private fun updateShortcut(shortcut: ShortcutInfoCompat): ShortcutInfoCompat {
        val conversation = conversationRepo.getConversation(shortcut.id.toLong())
        if (conversation == null) return shortcut
        else {
            val sc = createShortcutForConversation(conversation)
            ShortcutManagerCompat.pushDynamicShortcut(context, sc)
            return sc
        }
    }

    private fun getShortcuts(): List<ShortcutInfoCompat> {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
            return ShortcutManagerCompat.getDynamicShortcuts(context)
        } else {
            return emptyList()
        }
    }
}
