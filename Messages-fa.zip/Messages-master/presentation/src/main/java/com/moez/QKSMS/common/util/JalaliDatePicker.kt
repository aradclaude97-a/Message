/*
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.common.util

import android.app.AlertDialog
import android.content.Context
import android.view.View
import android.widget.LinearLayout
import android.widget.NumberPicker
import java.util.Calendar

/** A simple Jalali (Shamsi) date picker built from three number pickers. */
object JalaliDatePicker {

    /**
     * Builds the dialog. [onPicked] receives the chosen date as Gregorian year, 0-based month and
     * day of month, matching [android.app.DatePickerDialog.OnDateSetListener].
     */
    fun create(
        context: Context,
        initial: Calendar,
        onPicked: (year: Int, month: Int, day: Int) -> Unit,
    ): AlertDialog {
        val start = JalaliCalendar.fromCalendar(initial)

        val dayPicker = NumberPicker(context)
        val monthPicker = NumberPicker(context)
        val yearPicker = NumberPicker(context)

        yearPicker.minValue = start.year - 1
        yearPicker.maxValue = start.year + 20
        yearPicker.value = start.year
        yearPicker.wrapSelectorWheel = false
        yearPicker.setFormatter { JalaliCalendar.toPersianDigits(it) }

        monthPicker.minValue = 1
        monthPicker.maxValue = 12
        monthPicker.displayedValues = JalaliCalendar.monthNames
        monthPicker.value = start.month

        dayPicker.minValue = 1
        dayPicker.maxValue = JalaliCalendar.daysInMonth(start.year, start.month)
        dayPicker.value = start.day
        dayPicker.setFormatter { JalaliCalendar.toPersianDigits(it) }

        val refreshDays = {
            val max = JalaliCalendar.daysInMonth(yearPicker.value, monthPicker.value)
            dayPicker.maxValue = max
            if (dayPicker.value > max) dayPicker.value = max
        }
        monthPicker.setOnValueChangedListener { _, _, _ -> refreshDays() }
        yearPicker.setOnValueChangedListener { _, _, _ -> refreshDays() }

        val row =
            LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                val pad = (16 * resources.displayMetrics.density).toInt()
                setPadding(pad, pad, pad, pad)
                weightSum = 3f
                listOf(dayPicker, monthPicker, yearPicker).forEach { picker ->
                    addView(picker, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                }
            }

        return AlertDialog.Builder(context)
            .setView(row)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val (gy, gm, gd) =
                    JalaliCalendar.toGregorian(yearPicker.value, monthPicker.value, dayPicker.value)
                onPicked(gy, gm - 1, gd)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .create()
    }
}
