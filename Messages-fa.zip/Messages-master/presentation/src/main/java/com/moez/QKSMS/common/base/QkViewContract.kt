/*
 * SPDX-FileCopyrightText: 2018 Moez Bhatti <moez.bhatti@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.common.base

import androidx.lifecycle.LifecycleOwner

interface QkViewContract<in State> : LifecycleOwner {

    fun render(state: State)
}
