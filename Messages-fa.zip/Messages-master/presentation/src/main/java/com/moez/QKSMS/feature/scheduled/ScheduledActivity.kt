/*
 * SPDX-FileCopyrightText: 2018 Moez Bhatti <moez.bhatti@gmail.com>
 * SPDX-FileCopyrightText: Saalim Quadri <danascape@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.feature.scheduled

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AlertDialog
import androidx.core.view.isVisible
import androidx.lifecycle.ViewModelProvider
import com.jakewharton.rxbinding2.view.clicks
import dagger.android.AndroidInjection
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import javax.inject.Inject
import ir.pmessages.app.R
import ir.pmessages.app.common.base.QkThemedActivity
import ir.pmessages.app.common.util.extensions.setBackgroundTint
import ir.pmessages.app.common.util.extensions.setTint
import ir.pmessages.app.databinding.ScheduledActivityBinding

class ScheduledActivity :
    QkThemedActivity<ScheduledActivityBinding>(ScheduledActivityBinding::inflate), ScheduledView {

    @Inject lateinit var scheduledMessageAdapter: ScheduledMessageAdapter
    @Inject lateinit var viewModelFactory: ViewModelProvider.Factory

    override val composeIntent by lazy { binding.compose.clicks() }
    override val upgradeIntent by lazy { binding.upgrade.clicks() }
    override val messagesSelectedIntent by lazy { scheduledMessageAdapter.selectionChanges }
    override val optionsItemIntent: Subject<Int> = PublishSubject.create()
    override val deleteScheduledMessages: Subject<List<Long>> = PublishSubject.create()
    override val sendScheduledMessages: Subject<List<Long>> = PublishSubject.create()
    override val editScheduledMessage: Subject<Long> = PublishSubject.create()
    override val backPressedIntent: Subject<Unit> = PublishSubject.create()

    private val viewModel by lazy {
        ViewModelProvider(this, viewModelFactory)[ScheduledViewModel::class.java]
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setTitle(R.string.scheduled_title)
        showBackButton(true)
        viewModel.bindView(this)

        scheduledMessageAdapter.emptyView = binding.empty
        binding.messages.adapter = scheduledMessageAdapter

        colors.theme().let { theme ->
            binding.sampleMessage.setBackgroundTint(theme.theme)
            binding.sampleMessage.setTextColor(theme.textPrimary)
            binding.compose.setTint(theme.textPrimary)
            binding.compose.setBackgroundTint(theme.theme)
            binding.upgrade.setBackgroundTint(theme.theme)
            binding.upgradeIcon.setTint(theme.textPrimary)
            binding.upgradeLabel.setTextColor(theme.textPrimary)
        }
    }

    override fun render(state: ScheduledState) {
        scheduledMessageAdapter.updateData(state.scheduledMessages)

        setTitle(
            when {
                (state.selectedMessages > 0) ->
                    getString(R.string.compose_title_selected, state.selectedMessages)

                else -> getString(R.string.scheduled_title)
            }
        )

        // show/hide menu items
        binding.toolbar.menu.findItem(R.id.select_all)?.isVisible =
            ((scheduledMessageAdapter.itemCount > 1) && (state.selectedMessages != 0))
        binding.toolbar.menu.findItem(R.id.delete)?.isVisible =
            ((scheduledMessageAdapter.itemCount != 0) && (state.selectedMessages != 0))
        binding.toolbar.menu.findItem(R.id.copy)?.isVisible =
            ((scheduledMessageAdapter.itemCount != 0) && (state.selectedMessages != 0))
        binding.toolbar.menu.findItem(R.id.send_now)?.isVisible =
            ((scheduledMessageAdapter.itemCount != 0) && (state.selectedMessages != 0))
        binding.toolbar.menu.findItem(R.id.edit_message)?.isVisible =
            ((scheduledMessageAdapter.itemCount != 0) && (state.selectedMessages == 1))

        // show compose button
        binding.compose.isVisible = state.upgraded && (state.conversationId == null)
        binding.upgrade.isVisible = !state.upgraded
    }

    override fun onBackPressed() = backPressedIntent.onNext(Unit)

    override fun clearSelection() = scheduledMessageAdapter.clearSelection()

    override fun toggleSelectAll() = scheduledMessageAdapter.toggleSelectAll()

    override fun showDeleteDialog(messages: List<Long>) {
        val count = messages.size
        val dialog =
            AlertDialog.Builder(this, R.style.AppThemeDialog)
                .setTitle(R.string.dialog_delete_title)
                .setMessage(resources.getQuantityString(R.plurals.dialog_delete_chat, count, count))
                .setPositiveButton(R.string.button_delete) { _, _ ->
                    deleteScheduledMessages.onNext(messages)
                }
                .setNegativeButton(R.string.button_cancel, null)
                .create()

        dialog.show()
    }

    override fun showSendNowDialog(messages: List<Long>) {
        val count = messages.size
        val dialog =
            AlertDialog.Builder(this, R.style.AppThemeDialog)
                .setTitle(R.string.main_menu_send_now)
                .setMessage(resources.getQuantityString(R.plurals.dialog_send_now, count, count))
                .setPositiveButton(R.string.main_menu_send_now) { _, _ ->
                    sendScheduledMessages.onNext(messages)
                }
                .setNegativeButton(R.string.button_cancel, null)
                .create()

        dialog.show()
    }

    override fun showEditMessageDialog(message: Long) {
        val dialog =
            AlertDialog.Builder(this, R.style.AppThemeDialog)
                .setTitle(R.string.dialog_edit_scheduled_message_title)
                .setMessage(R.string.dialog_edit_scheduled_message)
                .setPositiveButton(R.string.dialog_edit_scheduled_message_positive_button) { _, _ ->
                    editScheduledMessage.onNext(message)
                }
                .setNegativeButton(R.string.button_cancel, null)
                .create()

        dialog.show()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.scheduled_messages, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        optionsItemIntent.onNext(item.itemId)
        return true
    }

    override fun finishActivity() {
        finish()
    }
}
