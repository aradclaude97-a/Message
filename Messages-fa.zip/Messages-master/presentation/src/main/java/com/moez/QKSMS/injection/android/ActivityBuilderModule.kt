/*
 * SPDX-FileCopyrightText: 2018 Moez Bhatti <moez.bhatti@gmail.com>
 * SPDX-FileCopyrightText: Saalim Quadri <danascape@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.injection.android

import dagger.Module
import dagger.android.ContributesAndroidInjector
import ir.pmessages.app.feature.backup.BackupActivity
import ir.pmessages.app.feature.blocking.BlockingActivity
import ir.pmessages.app.feature.classzero.ClassZeroActivity
import ir.pmessages.app.feature.compose.ComposeActivity
import ir.pmessages.app.feature.compose.ComposeActivityModule
import ir.pmessages.app.feature.contacts.ContactsActivity
import ir.pmessages.app.feature.contacts.ContactsActivityModule
import ir.pmessages.app.feature.conversationinfo.ConversationInfoActivity
import ir.pmessages.app.feature.gallery.GalleryActivity
import ir.pmessages.app.feature.gallery.GalleryActivityModule
import ir.pmessages.app.feature.main.MainActivity
import ir.pmessages.app.feature.main.MainActivityModule
import ir.pmessages.app.feature.notificationprefs.NotificationPrefsActivity
import ir.pmessages.app.feature.notificationprefs.NotificationPrefsActivityModule
import ir.pmessages.app.feature.plus.PlusActivity
import ir.pmessages.app.feature.plus.PlusActivityModule
import ir.pmessages.app.feature.qkreply.QkReplyActivity
import ir.pmessages.app.feature.qkreply.QkReplyActivityModule
import ir.pmessages.app.feature.scheduled.ScheduledActivity
import ir.pmessages.app.feature.scheduled.ScheduledActivityModule
import ir.pmessages.app.feature.settings.SettingsActivity
import ir.pmessages.app.injection.scope.ActivityScope

@Module
abstract class ActivityBuilderModule {

    @ActivityScope
    @ContributesAndroidInjector(modules = [MainActivityModule::class])
    abstract fun bindMainActivity(): MainActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [PlusActivityModule::class])
    abstract fun bindPlusActivity(): PlusActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindBackupActivity(): BackupActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [ComposeActivityModule::class])
    abstract fun bindComposeActivity(): ComposeActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindClassZeroActivity(): ClassZeroActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [ContactsActivityModule::class])
    abstract fun bindContactsActivity(): ContactsActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindConversationInfoActivity(): ConversationInfoActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [GalleryActivityModule::class])
    abstract fun bindGalleryActivity(): GalleryActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [NotificationPrefsActivityModule::class])
    abstract fun bindNotificationPrefsActivity(): NotificationPrefsActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [QkReplyActivityModule::class])
    abstract fun bindQkReplyActivity(): QkReplyActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [ScheduledActivityModule::class])
    abstract fun bindScheduledActivity(): ScheduledActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindSettingsActivity(): SettingsActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindBlockingActivity(): BlockingActivity
}
