/*
 * SPDX-FileCopyrightText: 2018 Moez Bhatti <moez.bhatti@gmail.com>
 * SPDX-FileCopyrightText: Saalim Quadri <danascape@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.feature.settings.about

import android.view.View
import com.jakewharton.rxbinding2.view.clicks
import io.reactivex.Observable
import javax.inject.Inject
import ir.pmessages.app.BuildConfig
import ir.pmessages.app.R
import ir.pmessages.app.common.base.QkController
import ir.pmessages.app.common.widget.PreferenceView
import ir.pmessages.app.databinding.AboutControllerBinding
import ir.pmessages.app.injection.appComponent

class AboutController : QkController<AboutView, Unit, AboutPresenter>(), AboutView {

    @Inject override lateinit var presenter: AboutPresenter

    private var _binding: AboutControllerBinding? = null
    private val binding
        get() = _binding!!

    init {
        appComponent.inject(this)
        layoutRes = R.layout.about_controller
    }

    override fun onAttach(view: View) {
        super.onAttach(view)
        _binding = AboutControllerBinding.bind(view)
        binding.version.summary = BuildConfig.VERSION_NAME
        presenter.bindIntents(this)
        setTitle(R.string.about_title)
        showBackButton(true)
    }

    override fun onDetach(view: View) {
        super.onDetach(view)
        _binding = null
    }

    override fun preferenceClicks(): Observable<PreferenceView> =
        (0 until binding.preferences.childCount)
            .map { index -> binding.preferences.getChildAt(index) }
            .mapNotNull { view -> view as? PreferenceView }
            .map { preference -> preference.clicks().map { preference } }
            .let { preferences -> Observable.merge(preferences) }

    override fun render(state: Unit) {
        // No special rendering required
    }
}
