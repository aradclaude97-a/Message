/*
 * SPDX-FileCopyrightText: 2018 Moez Bhatti <moez.bhatti@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.feature.scheduled

import io.realm.RealmResults
import ir.pmessages.app.model.ScheduledMessage

data class ScheduledState(
    val scheduledMessages: RealmResults<ScheduledMessage>? = null,
    val upgraded: Boolean = true,
    val selectedMessages: Int = 0,
    val conversationId: Long? = null,
)
