/*
 * SPDX-FileCopyrightText: 2018 Moez Bhatti <moez.bhatti@gmail.com>
 * SPDX-FileCopyrightText: Saalim Quadri <danascape@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.feature.compose.part

import android.content.Context
import javax.inject.Inject
import ir.pmessages.app.R
import ir.pmessages.app.common.base.QkViewHolder
import ir.pmessages.app.common.util.Colors
import ir.pmessages.app.common.util.extensions.setVisible
import ir.pmessages.app.common.widget.BubbleImageView
import ir.pmessages.app.databinding.MmsImagePreviewListItemBinding
import ir.pmessages.app.extensions.isImage
import ir.pmessages.app.extensions.isVideo
import ir.pmessages.app.model.Message
import ir.pmessages.app.model.MmsPart
import ir.pmessages.app.util.GlideApp

class ImageBinder @Inject constructor(colors: Colors, private val context: Context) : PartBinder() {

    override val partLayout = R.layout.mms_image_preview_list_item
    override var theme = colors.theme()

    override fun canBindPart(part: MmsPart) = part.isImage() || part.isVideo()

    override fun bindPart(
        holder: QkViewHolder,
        part: MmsPart,
        message: Message,
        canGroupWithPrevious: Boolean,
        canGroupWithNext: Boolean,
    ) {
        val binding = MmsImagePreviewListItemBinding.bind(holder.containerView)

        binding.video.setVisible(part.isVideo())
        holder.containerView.setOnClickListener { clicks.onNext(part.id) }

        binding.thumbnail.bubbleStyle =
            when {
                !canGroupWithPrevious && canGroupWithNext ->
                    if (message.isMe()) BubbleImageView.Style.OUT_FIRST
                    else BubbleImageView.Style.IN_FIRST
                canGroupWithPrevious && canGroupWithNext ->
                    if (message.isMe()) BubbleImageView.Style.OUT_MIDDLE
                    else BubbleImageView.Style.IN_MIDDLE
                canGroupWithPrevious && !canGroupWithNext ->
                    if (message.isMe()) BubbleImageView.Style.OUT_LAST
                    else BubbleImageView.Style.IN_LAST
                else -> BubbleImageView.Style.ONLY
            }

        GlideApp.with(context).load(part.getUri()).fitCenter().into(binding.thumbnail)
    }
}
