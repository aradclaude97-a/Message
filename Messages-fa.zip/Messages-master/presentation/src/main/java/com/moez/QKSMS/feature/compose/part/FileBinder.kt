/*
 * SPDX-FileCopyrightText: 2019 Moez Bhatti <moez.bhatti@gmail.com>
 * SPDX-FileCopyrightText: Saalim Quadri <danascape@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.feature.compose.part

import android.annotation.SuppressLint
import android.content.Context
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import javax.inject.Inject
import ir.pmessages.app.R
import ir.pmessages.app.common.Navigator
import ir.pmessages.app.common.base.QkViewHolder
import ir.pmessages.app.common.util.Colors
import ir.pmessages.app.common.util.extensions.resolveThemeColor
import ir.pmessages.app.common.util.extensions.setBackgroundTint
import ir.pmessages.app.common.util.extensions.setTint
import ir.pmessages.app.databinding.MmsFileListItemBinding
import ir.pmessages.app.feature.compose.BubbleUtils
import ir.pmessages.app.model.Message
import ir.pmessages.app.model.MmsPart

class FileBinder @Inject constructor(colors: Colors, private val context: Context) : PartBinder() {

    @Inject lateinit var navigator: Navigator

    override val partLayout = R.layout.mms_file_list_item
    override var theme = colors.theme()

    // This is the last binder we check. If we're here, we can bind the part
    override fun canBindPart(part: MmsPart) = true

    @SuppressLint("CheckResult")
    override fun bindPart(
        holder: QkViewHolder,
        part: MmsPart,
        message: Message,
        canGroupWithPrevious: Boolean,
        canGroupWithNext: Boolean,
    ) {
        val binding = MmsFileListItemBinding.bind(holder.containerView)

        BubbleUtils.getBubble(false, canGroupWithPrevious, canGroupWithNext, message.isMe())
            .let(binding.fileBackground::setBackgroundResource)

        Observable.just(part.getUri())
            .map(context.contentResolver::openInputStream)
            .map { inputStream -> inputStream.use { it.available() } }
            .map { bytes ->
                when (bytes) {
                    in 0..999 -> "$bytes B"
                    in 1000..999999 -> "${"%.1f".format(bytes / 1000f)} KB"
                    in 1000000..9999999 -> "${"%.1f".format(bytes / 1000000f)} MB"
                    else -> "${"%.1f".format(bytes / 1000000000f)} GB"
                }
            }
            .onErrorReturn { context.getString(R.string.compose_file_size_unavailable) }
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe { size -> binding.size.text = size }

        binding.filename.text = part.name

        if (!message.isMe()) {
            binding.fileBackground.setBackgroundTint(theme.theme)
            binding.icon.setTint(theme.textPrimary)
            binding.filename.setTextColor(theme.textPrimary)
            binding.size.setTextColor(theme.textTertiary)
        } else {
            binding.fileBackground.setBackgroundTint(
                holder.containerView.context.resolveThemeColor(R.attr.bubbleColor)
            )
            binding.icon.setTint(
                holder.containerView.context.resolveThemeColor(android.R.attr.textColorSecondary)
            )
            binding.filename.setTextColor(
                holder.containerView.context.resolveThemeColor(android.R.attr.textColorPrimary)
            )
            binding.size.setTextColor(
                holder.containerView.context.resolveThemeColor(android.R.attr.textColorTertiary)
            )
        }
    }
}
