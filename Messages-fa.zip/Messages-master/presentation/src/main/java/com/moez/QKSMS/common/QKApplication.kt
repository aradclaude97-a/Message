/*
 * SPDX-FileCopyrightText: 2017 Moez Bhatti <moez.bhatti@gmail.com>
 * SPDX-FileCopyrightText: Saalim Quadri <danascape@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.common

import android.app.Activity
import android.app.Application
import android.os.Bundle
import androidx.emoji2.bundled.BundledEmojiCompatConfig
import androidx.emoji2.text.EmojiCompat
import androidx.work.Configuration
import androidx.work.WorkManager
import androidx.work.WorkerFactory
import com.moez.QKSMS.manager.SpeakManager
import com.uber.rxdogtag.RxDogTag
import com.uber.rxdogtag.autodispose.AutoDisposeConfigurer
import dagger.android.AndroidInjector
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import io.reactivex.plugins.RxJavaPlugins
import io.realm.Realm
import io.realm.RealmConfiguration
import javax.inject.Inject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import ir.pmessages.app.BuildConfig
import ir.pmessages.app.R
import ir.pmessages.app.app.utils.AppUtil.applyEdgeToEdgeInsets
import ir.pmessages.app.common.util.FileLoggingTree
import ir.pmessages.app.common.util.plantWhile
import ir.pmessages.app.injection.AppComponentManager
import ir.pmessages.app.injection.appComponent
import ir.pmessages.app.interactor.SpeakThreads
import ir.pmessages.app.manager.BillingManager
import ir.pmessages.app.manager.ReferralManager
import ir.pmessages.app.migration.QkMigration
import ir.pmessages.app.migration.QkRealmMigration
import ir.pmessages.app.util.NightModeManager
import ir.pmessages.app.util.Preferences
import ir.pmessages.app.worker.HousekeepingWorker
import ir.pmessages.app.worker.SmsSendRetryWorker
import timber.log.Timber

class QKApplication : Application(), HasAndroidInjector {

    /** Inject these so that they are forced to initialize */
    @Suppress("unused") @Inject lateinit var qkMigration: QkMigration

    @Inject lateinit var billingManager: BillingManager

    @Inject lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    @Inject lateinit var fileLoggingTree: FileLoggingTree

    @Inject lateinit var nightModeManager: NightModeManager

    @Inject lateinit var prefs: Preferences

    @Inject lateinit var realmMigration: QkRealmMigration

    @Inject lateinit var referralManager: ReferralManager

    @Inject lateinit var workerFactory: WorkerFactory

    override fun onCreate() {
        super.onCreate()
        registerActivityLifecycle()

        // set application context for SpeakManager
        SpeakManager.setContext(this)

        // set translated "no messages" string for speakThreads interactor
        SpeakThreads.setNoMessagesString(getString(R.string.speak_no_messages))

        AppComponentManager.init(this)
        appComponent.inject(this)

        Realm.init(this)
        Realm.setDefaultConfiguration(
            RealmConfiguration.Builder()
                .compactOnLaunch()
                .migration(realmMigration)
                .schemaVersion(QkRealmMigration.SchemaVersion)
                .build()
        )

        qkMigration.performMigration()

        GlobalScope.launch(Dispatchers.IO) {
            referralManager.trackReferrer()
            billingManager.checkForPurchases()
            billingManager.queryProducts()
        }

        nightModeManager.updateCurrentTheme()

        // configure timber logging
        if (BuildConfig.DEBUG) Timber.plant(Timber.DebugTree())
        fileLoggingTree.plantWhile(prefs.logging.asObservable())

        // configure emoji compatibility with bundled package
        // (bundled library works with no play-services/gsm os versions)
        EmojiCompat.init(
            BundledEmojiCompatConfig(this)
                .registerInitCallback(
                    object : EmojiCompat.InitCallback() {
                        override fun onInitialized() {
                            super.onInitialized()
                            Timber.v("bundled emojicompat initialized")
                        }

                        override fun onFailed(throwable: Throwable?) {
                            super.onFailed(throwable)
                            Timber.e("bundled emojicompat initialization failed")
                        }
                    }
                )
        )

        // Handle undeliverable RxJava exceptions
        RxJavaPlugins.setErrorHandler { e -> Timber.w(e, "Undeliverable RxJava exception") }

        // rxdogtag provides 'look-back' for exceptions in rxjava2 'chains'
        RxDogTag.builder().configureWith(AutoDisposeConfigurer::configure).install()

        // init work manager with custom factory supporting dagger/injection capability
        WorkManager.initialize(
            this,
            Configuration.Builder().setWorkerFactory(workerFactory).build(),
        )

        // register, or re-register, housekeeping work manager
        HousekeepingWorker.register(applicationContext)

        SmsSendRetryWorker.kick(this, resetDelays = false)
    }

    private fun registerActivityLifecycle() {
        registerActivityLifecycleCallbacks(
            object : ActivityLifecycleCallbacks {
                override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
                    activity.applyEdgeToEdgeInsets()
                }

                override fun onActivityStarted(activity: Activity) {}

                override fun onActivityResumed(activity: Activity) {}

                override fun onActivityPaused(activity: Activity) {}

                override fun onActivityStopped(activity: Activity) {}

                override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}

                override fun onActivityDestroyed(activity: Activity) {}
            }
        )
    }

    override fun androidInjector(): AndroidInjector<Any> {
        return dispatchingAndroidInjector
    }
}
