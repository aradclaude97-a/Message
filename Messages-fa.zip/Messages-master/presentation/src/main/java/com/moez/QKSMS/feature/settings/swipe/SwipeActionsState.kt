/*
 * SPDX-FileCopyrightText: 2018 Moez Bhatti <moez.bhatti@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.feature.settings.swipe

import androidx.annotation.DrawableRes
import ir.pmessages.app.R

data class SwipeActionsState(
    @DrawableRes val rightIcon: Int = R.drawable.ic_archive_white_24dp,
    val rightLabel: String = "",
    @DrawableRes val leftIcon: Int = R.drawable.ic_archive_white_24dp,
    val leftLabel: String = "",
)
