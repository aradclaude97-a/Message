/*
 * SPDX-FileCopyrightText: 2018 Moez Bhatti <moez.bhatti@gmail.com>
 * SPDX-FileCopyrightText: Saalim Quadri <danascape@gmail.com>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package ir.pmessages.app.injection

import android.app.Application
import android.content.ContentResolver
import android.content.Context
import android.content.SharedPreferences
import android.preference.PreferenceManager
import androidx.lifecycle.ViewModelProvider
import androidx.work.WorkerFactory
import com.f2prateek.rx.preferences2.RxSharedPreferences
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import dagger.Module
import dagger.Provides
import javax.inject.Singleton
import ir.pmessages.app.blocking.BlockingClient
import ir.pmessages.app.blocking.BlockingManager
import ir.pmessages.app.common.ViewModelFactory
import ir.pmessages.app.common.util.BillingManagerImpl
import ir.pmessages.app.common.util.NotificationManagerImpl
import ir.pmessages.app.common.util.ShortcutManagerImpl
import ir.pmessages.app.feature.conversationinfo.injection.ConversationInfoComponent
import ir.pmessages.app.feature.themepicker.injection.ThemePickerComponent
import ir.pmessages.app.listener.ContactAddedListener
import ir.pmessages.app.listener.ContactAddedListenerImpl
import ir.pmessages.app.manager.ActiveConversationManager
import ir.pmessages.app.manager.ActiveConversationManagerImpl
import ir.pmessages.app.manager.AlarmManager
import ir.pmessages.app.manager.AlarmManagerImpl
import ir.pmessages.app.manager.BillingManager
import ir.pmessages.app.manager.ChangelogManager
import ir.pmessages.app.manager.ChangelogManagerImpl
import ir.pmessages.app.manager.KeyManager
import ir.pmessages.app.manager.KeyManagerImpl
import ir.pmessages.app.manager.MmsDownloadPolicy
import ir.pmessages.app.manager.MmsDownloadPolicyImpl
import ir.pmessages.app.manager.NotificationManager
import ir.pmessages.app.manager.PermissionManager
import ir.pmessages.app.manager.PermissionManagerImpl
import ir.pmessages.app.manager.RatingManager
import ir.pmessages.app.manager.ReferralManager
import ir.pmessages.app.manager.ReferralManagerImpl
import ir.pmessages.app.manager.ShortcutManager
import ir.pmessages.app.manager.WidgetManager
import ir.pmessages.app.manager.WidgetManagerImpl
import ir.pmessages.app.mapper.CursorToContact
import ir.pmessages.app.mapper.CursorToContactGroup
import ir.pmessages.app.mapper.CursorToContactGroupImpl
import ir.pmessages.app.mapper.CursorToContactGroupMember
import ir.pmessages.app.mapper.CursorToContactGroupMemberImpl
import ir.pmessages.app.mapper.CursorToContactImpl
import ir.pmessages.app.mapper.CursorToConversation
import ir.pmessages.app.mapper.CursorToConversationImpl
import ir.pmessages.app.mapper.CursorToMessage
import ir.pmessages.app.mapper.CursorToMessageImpl
import ir.pmessages.app.mapper.CursorToPart
import ir.pmessages.app.mapper.CursorToPartImpl
import ir.pmessages.app.mapper.CursorToRecipient
import ir.pmessages.app.mapper.CursorToRecipientImpl
import ir.pmessages.app.mapper.RatingManagerImpl
import ir.pmessages.app.repository.BackupRepository
import ir.pmessages.app.repository.BackupRepositoryImpl
import ir.pmessages.app.repository.BlockingRepository
import ir.pmessages.app.repository.BlockingRepositoryImpl
import ir.pmessages.app.repository.ContactRepository
import ir.pmessages.app.repository.ContactRepositoryImpl
import ir.pmessages.app.repository.ConversationRepository
import ir.pmessages.app.repository.ConversationRepositoryImpl
import ir.pmessages.app.repository.EmojiReactionRepository
import ir.pmessages.app.repository.EmojiReactionRepositoryImpl
import ir.pmessages.app.repository.MessageContentFilterRepository
import ir.pmessages.app.repository.MessageContentFilterRepositoryImpl
import ir.pmessages.app.repository.MessageRepository
import ir.pmessages.app.repository.MessageRepositoryImpl
import ir.pmessages.app.repository.ScheduledMessageRepository
import ir.pmessages.app.repository.ScheduledMessageRepositoryImpl
import ir.pmessages.app.repository.SyncRepository
import ir.pmessages.app.repository.SyncRepositoryImpl
import ir.pmessages.app.worker.InjectionWorkerFactory

@Module(subcomponents = [ConversationInfoComponent::class, ThemePickerComponent::class])
class AppModule(private var application: Application) {

    @Provides @Singleton fun provideContext(): Context = application

    @Provides
    fun provideContentResolver(context: Context): ContentResolver = context.contentResolver

    @Provides
    @Singleton
    fun provideSharedPreferences(context: Context): SharedPreferences {
        return PreferenceManager.getDefaultSharedPreferences(context)
    }

    @Provides
    @Singleton
    fun provideRxPreferences(preferences: SharedPreferences): RxSharedPreferences {
        return RxSharedPreferences.create(preferences)
    }

    @Provides
    @Singleton
    fun provideMoshi(): Moshi {
        return Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
    }

    @Provides
    fun provideViewModelFactory(factory: ViewModelFactory): ViewModelProvider.Factory = factory

    // Listener

    @Provides
    fun provideContactAddedListener(listener: ContactAddedListenerImpl): ContactAddedListener =
        listener

    // Manager

    @Provides fun provideBillingManager(manager: BillingManagerImpl): BillingManager = manager

    @Provides
    fun provideActiveConversationManager(
        manager: ActiveConversationManagerImpl
    ): ActiveConversationManager = manager

    @Provides fun provideAlarmManager(manager: AlarmManagerImpl): AlarmManager = manager

    @Provides fun blockingClient(manager: BlockingManager): BlockingClient = manager

    @Provides fun changelogManager(manager: ChangelogManagerImpl): ChangelogManager = manager

    @Provides fun provideKeyManager(manager: KeyManagerImpl): KeyManager = manager

    @Provides
    fun provideNotificationsManager(manager: NotificationManagerImpl): NotificationManager = manager

    @Provides
    fun providePermissionsManager(manager: PermissionManagerImpl): PermissionManager = manager

    @Provides fun provideRatingManager(manager: RatingManagerImpl): RatingManager = manager

    @Provides fun provideShortcutManager(manager: ShortcutManagerImpl): ShortcutManager = manager

    @Provides fun provideReferralManager(manager: ReferralManagerImpl): ReferralManager = manager

    @Provides
    fun provideMmsDownloadPolicy(policy: MmsDownloadPolicyImpl): MmsDownloadPolicy = policy

    @Provides fun provideWidgetManager(manager: WidgetManagerImpl): WidgetManager = manager

    // Mapper

    @Provides fun provideCursorToContact(mapper: CursorToContactImpl): CursorToContact = mapper

    @Provides
    fun provideCursorToContactGroup(mapper: CursorToContactGroupImpl): CursorToContactGroup = mapper

    @Provides
    fun provideCursorToContactGroupMember(
        mapper: CursorToContactGroupMemberImpl
    ): CursorToContactGroupMember = mapper

    @Provides
    fun provideCursorToConversation(mapper: CursorToConversationImpl): CursorToConversation = mapper

    @Provides fun provideCursorToMessage(mapper: CursorToMessageImpl): CursorToMessage = mapper

    @Provides fun provideCursorToPart(mapper: CursorToPartImpl): CursorToPart = mapper

    @Provides
    fun provideCursorToRecipient(mapper: CursorToRecipientImpl): CursorToRecipient = mapper

    // Repository

    @Provides
    fun provideBackupRepository(repository: BackupRepositoryImpl): BackupRepository = repository

    @Provides
    fun provideBlockingRepository(repository: BlockingRepositoryImpl): BlockingRepository =
        repository

    @Provides
    fun provideMessageContentFilterRepository(
        repository: MessageContentFilterRepositoryImpl
    ): MessageContentFilterRepository = repository

    @Provides
    fun provideContactRepository(repository: ContactRepositoryImpl): ContactRepository = repository

    @Provides
    fun provideConversationRepository(
        repository: ConversationRepositoryImpl
    ): ConversationRepository = repository

    @Provides
    fun provideMessageRepository(repository: MessageRepositoryImpl): MessageRepository = repository

    @Provides
    fun provideScheduledMessagesRepository(
        repository: ScheduledMessageRepositoryImpl
    ): ScheduledMessageRepository = repository

    @Provides fun provideSyncRepository(repository: SyncRepositoryImpl): SyncRepository = repository

    @Provides
    fun provideEmojiReactionRepository(
        repository: EmojiReactionRepositoryImpl
    ): EmojiReactionRepository = repository

    // worker factory
    @Provides
    fun provideWorkerFactory(workerFactory: InjectionWorkerFactory): WorkerFactory = workerFactory
}
